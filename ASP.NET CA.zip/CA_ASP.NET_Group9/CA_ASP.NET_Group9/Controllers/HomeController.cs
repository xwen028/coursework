﻿using System.Collections.Generic;
using System;
using System.Diagnostics;
using CA_ASP.NET_Group9.Models;
using Microsoft.AspNetCore.Mvc;
using static System.Net.Mime.MediaTypeNames;
using System.Runtime.InteropServices;
using System.Data.SqlTypes;
using System.IO.Pipelines;

namespace CA_ASP.NET_Group9.Controllers
{
    public class HomeController : Controller
    {
        private List<Item> ItemsList = new List<Item>();
        private List<int> ItemNumber = new List<int>();
        private readonly ILogger<HomeController> _logger;
        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
            ItemsList.Add(new Item
            {
                ItemName = ".NET Charts",
                Description = " Brings powerful charting capabilities to your .NET applications",
                Price = 99,
                Image = "/Images/Charts.png"
            });
            ItemsList.Add(new Item
            {
                ItemName = ".NET PayPal",
                Description = " Integrate your .NET apps with PayPal the easy way",
                Price = 69,
                Image = "/Images/PayPal.jpg"
            });
            ItemsList.Add(new Item
            {
                ItemName = ".NET ML",
                Description = " Supercharged .NET machine learning libraries",
                Price = 299,
                Image = "/Images/ML.png"
            });
            ItemsList.Add(new Item
            {
                ItemName = ".NET Analytics",
                Description = " Performs data mining and analytics easily in .NET",
                Price = 299,
                Image = "/Images/Analytics.png"
            });
            ItemsList.Add(new Item
            {
                ItemName = ".NET Logger",
                Description = " Logs and aggregates events easily in your .NET apps",
                Price = 49,
                Image = "/Images/Logger.png"
            });
            ItemsList.Add(new Item
            {
                ItemName = ".NET Numerics",
                Description = " Powerful numerical methods for your .NET simulations",
                Price = 199,
                Image = "/Images/Numerics.jpg"
            });
            for (int i = 0; i < ItemsList.Count(); i++)
            {
                ItemNumber.Add(1);
            }
        }
    public IActionResult Login()
        {
            return View();
        }
    public IActionResult LogOut()
        {
            return View();
        }
    public IActionResult Gallery(string Username)
        {
            ViewBag.Items = ItemsList;
            ViewBag.Username = Username;
            return View();
        }
    public IActionResult GalleryOnClick(string Substring)
        {
            ViewBag.Items = ItemsList;
            ViewBag.Substring = Substring;
            return View();
        }
        [HttpPost]
        public IActionResult AddToCart(IFormCollection form)
        {
            string itemName = form["itemName"];
            for (int i = 0;i < ItemsList.Count; i++)
            {
                ItemNumber[i]++;
                if (ItemsList[i].ItemName == itemName)
                {
                    ItemNumber[i]++;
                    break;
                }
            }
            return View();
        }
    public IActionResult MyPurchase()
    {
        ViewBag.Items = ItemsList;
        return View();
    }
    public IActionResult ViewCart()
    {
        ViewBag.Items = ItemsList;
        ViewBag.ItemNumber = ItemNumber;
        return View();
    }
        /*
        public List<Item> GetItemDetails()
        {
            List<Item> Items = new List<Item>();
            List<ItemInCart> ItemsInCart = new List<ItemInCart>();
            Items.Add(new Item
            {
                ItemName = ".NET Charts",
                Description = " Brings powerful charting capabilities to your .NET applications",
                Price = 99,
                Image = "/Images/Charts.png"
            });
            Items.Add(new Item
            {
                ItemName = ".NET PayPal",
                Description = " Integrate your .NET apps with PayPal the easy way",
                Price = 69,
                Image = "/Images/PayPal.jpg"
            });
            Items.Add(new Item
            {
                ItemName = ".NET ML",
                Description = " Supercharged .NET machine learning libraries",
                Price = 299,
                Image = "/Images/ML.png"
            });
            Items.Add(new Item
            {
                ItemName = ".NET Analytics",
                Description = " Performs data mining and analytics easily in .NET",
                Price = 299,
                Image = "/Images/Analytics.png"
            });
            Items.Add(new Item
            {
                ItemName = ".NET Logger",
                Description = " Logs and aggregates events easily in your .NET apps",
                Price = 49,
                Image = "/Images/Logger.png"
            });
            Items.Add(new Item
            {
                ItemName = ".NET Numerics",
                Description = " Powerful numerical methods for your .NET simulations",
                Price = 199,
                Image = "/Images/Numerics.jpg"
            });
            return Items;
        }

        */

            [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}