﻿using System;

namespace CA_ASP.NET_Group9.Models
{
    public class Item
    {
        public string? ItemName { get; set; }
        public string? Description { get; set; }
        public decimal Price { get; set; }
        public string? Image { get; set;}
    }

}
