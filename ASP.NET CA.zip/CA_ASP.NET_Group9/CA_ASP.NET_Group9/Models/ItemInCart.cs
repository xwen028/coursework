﻿namespace CA_ASP.NET_Group9.Models
{
    public class ItemInCart
    {
        public string? ItemName { get; set; }
        public int Quantity { get; set; }
    }
}
