package iss.workshop.android_ca;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.ObjectAnimator;
import android.app.AlertDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.os.Bundle;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import android.content.Intent;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.SystemClock;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.ImageView;
import android.os.Environment;
import android.widget.TextView;
import android.view.LayoutInflater;
import android.app.Activity;
import android.content.Context;

import nl.dionsegijn.konfetti.core.PartyFactory;
import nl.dionsegijn.konfetti.core.Position;
import nl.dionsegijn.konfetti.core.emitter.Emitter;
import nl.dionsegijn.konfetti.core.emitter.EmitterConfig;
import nl.dionsegijn.konfetti.core.models.Shape;
import nl.dionsegijn.konfetti.xml.KonfettiView;

public class GameActivity extends AppCompatActivity {
    protected TextView matchTxt;
    protected int matches;
    protected Chronometer chronometer;
    protected ArrayList<String> imagesSelected;
    protected HashMap<Integer, String> imagesPosition = new HashMap<Integer, String>(); // Key is imageViewId, Value is imageFileName
    protected MediaPlayer mediaPlayer;
    protected KonfettiView konfettiView;
    protected boolean twoPlayer;
    protected int playerNumber;
    protected HashMap<Integer, String> playerTime = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        matchTxt = findViewById(R.id.matchTxt);
        matches = 0;
        chronometer = (Chronometer) findViewById(R.id.time);

        Intent intent = getIntent();

        twoPlayer = intent.getBooleanExtra("twoPlayer", false);
        playerNumber = 0;

        imagesSelected = intent.getStringArrayListExtra("imagesSelected");
        // Duplicate the fileNames so we can get pairs
        for (int i = 0; i < 6; i ++){
            imagesSelected.add(imagesSelected.get(i));
        }
        setImageToImageView();
        setListenerForImageView();
        if (twoPlayer){
            playerNumber = 1;
            showPlayerStart();
        }
        else{
            chronometer.start();
        }
    }

    protected void setImageToImageView(){
        // Get an array of int 1-12
        ArrayList<Integer> positionsAvailable = new ArrayList<Integer>();
        for (int i = 0; i < 12; i++){
            positionsAvailable.add(i);
        }
        // Shuffle the int in the array
        Collections.shuffle(positionsAvailable);
        // Assign image view to each int in the array and save in Hashmap
        for (int i = 0; i < 12; i++){
            int position = positionsAvailable.get(i);
            int imageViewId = getResources().getIdentifier("imageView" + position, "id", getPackageName());
            imagesPosition.put(imageViewId, imagesSelected.get(i));
        }
    }

    protected void setListenerForImageView(){
        // Set on click listener
        for (int i = 0; i < 12; i++){
            int imageViewId = getResources().getIdentifier("imageView" + i, "id", getPackageName());
            ImageView imageView = findViewById(imageViewId);
            imageView.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    int imageViewId = v.getId();
                    String imageFileName = imagesPosition.get(imageViewId);

                    File picturesDirectory = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
                    String filePath = picturesDirectory.getAbsolutePath() + File.separator + imageFileName;
                    File image = new File(filePath);

                    if (image.exists()) {
                        Bitmap bitmap = BitmapFactory.decodeFile(image.getAbsolutePath());
                        // Flip card animation for when showing the images
                        imageView.animate().withLayer().rotationY(90).setDuration(150).withEndAction(new Runnable() {
                            @Override public void run() {
                                imageView.setImageBitmap(bitmap);
                                // second quarter turn
                                imageView.setRotationY(-90);
                                imageView.animate().withLayer().rotationY(0).setDuration(150).start();
                            }
                        }).start();
                        imageView.setSelected(true);
                        checkSelected();
                    }
                }
            });
        }
    }

    protected void checkSelected(){
        // Check how many selected
        ArrayList<Integer> imageViewIdsSelected = new ArrayList<Integer>();
        for (int i = 0; i < 12; i++) {
            int imageViewId = getResources().getIdentifier("imageView" + i, "id", getPackageName());
            ImageView imageView = findViewById(imageViewId);
            if (imageView.isSelected()) {
                imageViewIdsSelected.add(imageViewId);
            }
        }
        if (imageViewIdsSelected.size() == 2){
            // Check if same imageFileName
            String fileName1 = imagesPosition.get(imageViewIdsSelected.get(0));
            String fileName2 = imagesPosition.get(imageViewIdsSelected.get(1));
            if (fileName1.equals(fileName2)){
                // If images match, increase score, clear selection
                matches ++;
                matchTxt.setText(matches + " of 6 matches");
                for (Integer id : imageViewIdsSelected){
                    ImageView imageView = findViewById(id);
                    imageView.setSelected(false);
                }
                // Play correct sound
                mediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.correct);
                mediaPlayer.start();
                if (matches == 6){
                    //Stop Time
                    chronometer.stop();
                    if (playerNumber == 0){
                        String timeTaken = "Time taken: " + chronometer.getText().toString();
                        endGame("You Win!", timeTaken);
                    }
                    else if (playerNumber == 1){
                        playerTime.put(playerNumber, chronometer.getText().toString());
                        startNextGame();
                    }
                    else{ // playerNumber == 2
                        playerTime.put(playerNumber, chronometer.getText().toString());
                        displayWinner();
                    }
                }
            }
            else {
                // If mismatch, flip back both images after delay, clear selection
                // Play wrong sound
                mediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.wrong);
                mediaPlayer.start();
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        for (Integer id : imageViewIdsSelected){
                            ImageView imageView = findViewById(id);
                            flipCard(imageView);
                            imageView.setSelected(false);
                        }
                    }
                }, 1000);
            }
        }
    }

    protected void endGame(String text1, String text2){
        LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
        View popupView = inflater.inflate(R.layout.popup, null);
        Button replayBtn = popupView.findViewById(R.id.replayBtn);

        // Set text1
        TextView popupTxt = popupView.findViewById(R.id.popupTxt);
        popupTxt.setText(text1);

        // Set text2
        TextView timeTxt = popupView.findViewById(R.id.timeTxt);
        timeTxt.setText(text2);

        // Set on click listener for replay button in popup
        replayBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(GameActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        // Show popup
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(popupView);
        AlertDialog dialog = builder.create();

        // Set up animation
        Animation fade = AnimationUtils.loadAnimation(this, R.anim.fade);
        // Apply the animation to the dialog's view
        dialog.getWindow().getDecorView().setAnimation(fade);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                dialog.show();
                mediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.win);
                mediaPlayer.start();
                showKonfetti();
            }
        }, 1000);
    }

    protected void flipCard(ImageView imageView){
        // Flip card animation for turning back to greenbox placeholder
        imageView.animate().withLayer().rotationY(90).setDuration(150).withEndAction(new Runnable() {
            @Override public void run() {
                imageView.setImageResource(R.drawable.greenbox);
                // second quarter turn
                imageView.setRotationY(-90);
                imageView.animate().withLayer().rotationY(0).setDuration(150).start();
            }
        }).start();
    }

    protected void showKonfetti(){
        konfettiView = findViewById(R.id.konfettiView);
        EmitterConfig emitterConfig = new Emitter(100L, TimeUnit.MILLISECONDS).max(100);
        konfettiView.start(
                new PartyFactory(emitterConfig)
                        .spread(360)
                        .shapes(Arrays.asList(Shape.Square.INSTANCE, Shape.Circle.INSTANCE))
                        .colors(Arrays.asList(0xfce18a, 0xff726d, 0xf4306d, 0xb48def))
                        .setSpeedBetween(0f, 30f)
                        .position(new Position.Relative(0.5, 0.3))
                        .build());
    }

    protected void showPlayerStart(){
        LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
        View playerView = inflater.inflate(R.layout.player_start, null);
        TextView playerTxt = playerView.findViewById(R.id.playerTxt);
        playerTxt.setText("Player " + playerNumber);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(playerView);
        AlertDialog dialog = builder.create();

        Button startBtn = playerView.findViewById(R.id.startBtn);
        startBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (playerNumber == 2){
                    clearCards();
                    matches = 0;
                    matchTxt.setText("0 of 6 matches");
                }
                dialog.dismiss();
                chronometer.setBase(SystemClock.elapsedRealtime());
                chronometer.start();
            }
        });
        dialog.show();
    }

    protected void startNextGame(){
        playerNumber = 2;
        setImageToImageView();
        setListenerForImageView();
        showPlayerStart();
    }

    protected void clearCards(){
        // Set all imageView back to placeholder
        for (int i = 0; i < 12; i++) {
            int imageViewId = getResources().getIdentifier("imageView" + i, "id", getPackageName());
            ImageView imageView = findViewById(imageViewId);
            imageView.setImageResource(R.drawable.greenbox);
        }
    }

    protected void displayWinner(){
        String text1 = "";
        String text2 = "";
        int player1Time = findWinner(playerTime.get(1));
        int player2Time = findWinner(playerTime.get(2));
        System.out.println("player1Time: " + player1Time);
        System.out.println("player2Time: " + player2Time);
        if (player1Time < player2Time){
            text1 = "Player 1 Wins!";
        }
        else if (player2Time < player1Time){
            text1 = "Player 2 Wins!";
        }
        else{
            text1 = "It's a Draw!";
        }
        text2 = "Player 1: " + playerTime.get(1) + " vs Player 2: " + playerTime.get(2);
        endGame(text1, text2);
    }

    protected int findWinner(String timing){
        String[] time = timing.split(":");
        int seconds = (Integer.parseInt(time[0]) * 60) + Integer.parseInt(time[1]);
        System.out.println("Integer.parseInt(time[0])" + Integer.parseInt(time[0]));
        System.out.println("Integer.parseInt(time[1])" + Integer.parseInt(time[1]));
        return seconds;
    }
}