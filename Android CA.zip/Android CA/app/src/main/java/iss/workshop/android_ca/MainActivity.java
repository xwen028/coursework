package iss.workshop.android_ca;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Environment;
import android.widget.ImageView;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    protected Button fetchBtn;
    protected ProgressBar progressBar;
    protected TextView progressText;
    protected Button goBtn;
    protected Switch playerSwitch;
    protected TextView selectImgText;
    Thread bkgdThread;
    ArrayList<String> imagesSelected;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fetchBtn = findViewById(R.id.fetchBtn);
        fetchBtn.setOnClickListener(this);
        progressBar = findViewById(R.id.progressBar);
        progressText = findViewById(R.id.progressText);
        goBtn = findViewById(R.id.goBtn);
        playerSwitch = findViewById(R.id.playerSwitch);
        selectImgText = findViewById(R.id.selectImgText);


        goBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, GameActivity.class);
                intent.putExtra("imagesSelected", imagesSelected);
                intent.putExtra("twoPlayer", playerSwitch.isChecked());
                startActivity(intent);
            }
        });
    }

    @Override
    public void onClick(View v) {
        EditText urlField = findViewById(R.id.url);
        String webpageURL = urlField.getText().toString();
        if (bkgdThread != null) {
            bkgdThread.interrupt();
        }
        // Set progress bar back to 0
        progressBar.setProgress(0);
        progressText.setText("Downloading 0 of 0 images");
        clearImageViews();
        imagesSelected = new ArrayList<String>();
        progressBar.setVisibility(View.VISIBLE);
        progressText.setVisibility(View.VISIBLE);
        selectImgText.setVisibility(View.GONE);
        goBtn.setVisibility(View.GONE);
        playerSwitch.setVisibility(View.GONE);
        startDownloadImage(webpageURL);
    }

    protected void startDownloadImage(String webpageURL) {
        File destDirectory = getExternalFilesDir(Environment.DIRECTORY_PICTURES);

        // creating a background thread
        bkgdThread = new Thread(new Runnable() {
            @Override
            public void run() {
                List<String> imageUrls = new ArrayList<>();
                try {
                    // Use jsoup to parse HTML file
                    Document document = Jsoup.connect(webpageURL).get();
                    // Find image elements that are jpg or png
                    Elements imgElements = document.select("img[src$=.jpg], img[src$=.png]");

                    for (int i = 0; i < Math.min(imgElements.size(), 20); i++) {
                        String imgURL = imgElements.get(i).absUrl("src");
                        imageUrls.add(imgURL);
                    }
                }
                catch (Exception e) {
                    System.out.println("Exception");
                }

                ImageDownloader imgDL = new ImageDownloader();
                for (int i = 0; i < imageUrls.size(); i++){
                    if (imgDL.downloadImage(imageUrls.get(i), destDirectory, i)){
                        int finalI = i;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                String filename = "image_" + finalI + ".jpg";
                                File image = new File(destDirectory, filename);
                                Bitmap bitmap = BitmapFactory.decodeFile(image.getAbsolutePath());
                                int imageViewId = getResources().getIdentifier("imageView" + finalI, "id", getPackageName());
                                ImageView imageView = findViewById(imageViewId);
                                imageView.setImageBitmap(bitmap);
                                imageView.setOnClickListener(v -> {
                                    if (!v.isSelected()){
                                        v.setSelected(true);
                                        imagesSelected.add(filename);
                                        imageView.setColorFilter(Color.rgb(123, 123, 123), android.graphics.PorterDuff.Mode.MULTIPLY);
                                    }
                                    else{
                                        v.setSelected(false);
                                        imagesSelected.remove(filename);
                                        imageView.clearColorFilter();
                                    }
                                    checkSelected();
                                });
                                int progress = ((finalI + 1)  * 100) / imageUrls.size();
                                progressBar.setProgress(progress);
                                if (finalI < imageUrls.size()-1){
                                    progressText.setText("Downloading " + (finalI+1) + " of " + imageUrls.size() + " images");
                                }
                                else {
                                    progressText.setText("Downloaded " + imageUrls.size() + " of " + imageUrls.size() + " images");
                                    new Handler().postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            progressBar.setVisibility(View.GONE);
                                            progressText.setVisibility(View.GONE);
                                            selectImgText.setVisibility(View.VISIBLE);
                                        }
                                    }, 1000);
                                }
                            }
                        });
                    }
                    else{
                        // If thread interrupted, and exception caught, stop downloading process
                        break;
                    }
                }
                System.out.println("Out of for loop broken");
                // done downloading; release thread
                bkgdThread = null;
            }
        });
        bkgdThread.start();
    }

    protected void checkSelected(){
        int count = 0;
        for (int i = 0; i < 20; i++){
            int imageViewId = getResources().getIdentifier("imageView" + i, "id", getPackageName());
            ImageView imageView = findViewById(imageViewId);
            if (imageView.isSelected()){
                count++;
            }
        }
        if (count == 6){
            selectImgText.setVisibility(View.GONE);
            goBtn.setVisibility(View.VISIBLE);
            playerSwitch.setVisibility(View.VISIBLE);
        }
        else{
            selectImgText.setVisibility(View.VISIBLE);
            goBtn.setVisibility(View.GONE);
            playerSwitch.setVisibility(View.GONE);
        }
    }

    protected void clearImageViews(){
        for (int i = 0; i < 20; i++) {
            int imageViewId = getResources().getIdentifier("imageView" + i, "id", getPackageName());
            ImageView imageView = findViewById(imageViewId);
            imageView.setImageResource(0);
            imageView.setSelected(false);
            imageView.clearColorFilter();
        }
    }
}