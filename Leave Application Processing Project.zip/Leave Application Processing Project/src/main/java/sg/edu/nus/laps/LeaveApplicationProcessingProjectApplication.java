package sg.edu.nus.laps;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LeaveApplicationProcessingProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(LeaveApplicationProcessingProjectApplication.class, args);
	}

}
