package sg.edu.nus.laps.controller;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import sg.edu.nus.laps.interfacemethods.ApplicationInterface;
import sg.edu.nus.laps.interfacemethods.HolidayInterface;
import sg.edu.nus.laps.interfacemethods.UserInterface;
import sg.edu.nus.laps.model.LeaveApplication;
import sg.edu.nus.laps.model.User;
import sg.edu.nus.laps.service.ApplicationImplementation;
import sg.edu.nus.laps.service.EmailService;
import sg.edu.nus.laps.service.HolidayImplementation;
import sg.edu.nus.laps.service.UserImplementation;

@Controller
@RequestMapping("/application")
public class ApplicationController {
	@Autowired
	private ApplicationInterface aservice;
	private UserInterface uservice;
	private HolidayInterface hservice;
	private EmailService eservice;

	@Autowired
	public void setProductService(ApplicationImplementation aserviceImpl, UserImplementation userviceImpl,
			HolidayImplementation hserviceImpl,EmailService eservice) {
		this.aservice = aserviceImpl;
		this.uservice = userviceImpl;
		this.hservice = hserviceImpl;
		this.eservice = eservice;
	}

	@RequestMapping("/create")
	public String createApplication(@RequestParam("leaveType") String leaveType,
			@RequestParam("startDate") LocalDate startDate, @RequestParam("endDate") LocalDate endDate,
			@RequestParam("additionalReason") String additionalReason,
			@RequestParam("workDissemination") String workDissemination,
			@RequestParam("contactDetail") String contactDetail, HttpSession sessionObj) {
		String userId = (String) sessionObj.getAttribute("userId");
		if (userId == null) {
			return "redirect:/user/login";
		}
		User user = uservice.findUser(userId);
		long daysDifference = ChronoUnit.DAYS.between(startDate, endDate);
		long weekends = 0;
		LocalDate date = startDate;
		while (!date.isAfter(endDate)) {
			if (date.getDayOfWeek() == DayOfWeek.SATURDAY || date.getDayOfWeek() == DayOfWeek.SUNDAY) {
				weekends++;
			}
			date = date.plusDays(1);
		}
		long workingDaysDifference = daysDifference + 1 - weekends;
		int holiday = hservice.countHolidayBetween(startDate, endDate);
		int leavePeriod = (int) workingDaysDifference - holiday;
		if (leavePeriod > 0) {
			if (leavePeriod > uservice.findLeaveLeft(userId, leaveType)) {
				sessionObj.setAttribute("wrongmessage", "You don't have enough leaves!");
				return "redirect:/user/createapplication";
			}
			// create
			aservice.createApplication(leaveType, startDate, endDate, user, additionalReason, workDissemination,
					contactDetail, leavePeriod);
			// e-mail
			String managerId = user.getManagerId();
			User manager = uservice.findUser(managerId);
			String recipientEmail = manager.getEmailAddress();
			eservice.sendEmailToManager(recipientEmail, userId);
			return "redirect:/";
		}
		sessionObj.setAttribute("wrongmessage", "Wrong Leave Period, please enter right dates!");
		return "redirect:/user/createapplication";
	}

	@RequestMapping("/historylist")
	public String showHistoryApplications(HttpSession sessionObj, Model model) {
		String userId = (String) sessionObj.getAttribute("userId");
		if (userId == null) {
			return "redirect:/user/login";
		}
		List<LeaveApplication> allrecords = new ArrayList<>();
		allrecords = aservice.findAllByUserId(userId);
		int len = allrecords.size();
		model.addAttribute("historys", allrecords);
		model.addAttribute("numberofrecords", len);
		model.addAttribute("start", 0);
		model.addAttribute("end", len);
		return "applicationHistoryPage";
	}

	@RequestMapping("/historylist/{number}/{start}")
	public String showHistoryApplicationsPagination(@PathVariable("number") Integer number,
			@PathVariable("start") Integer start, HttpSession sessionObj, Model model) {
		String userId = (String) sessionObj.getAttribute("userId");
		if (userId == null) {
			return "redirect:/user/login";
		}
		List<LeaveApplication> allrecords = new ArrayList<>();
		allrecords = aservice.findAllByUserId(userId);
		int len = allrecords.size();
		List<LeaveApplication> records = new ArrayList<>();
		int end = start + number;
		if (end > len) {
			end = len;
		}
		for (int i = start; i < end; i++) {
			records.add(allrecords.get(i));
		}
		model.addAttribute("historys", records);
		model.addAttribute("numberofrecords", len);
		model.addAttribute("start", start);
		model.addAttribute("end", end);
		return "applicationHistoryPage";
	}

	@RequestMapping("/subordinatehistorylist")
	public String showSubordinateHistoryApplications(HttpSession sessionObj, Model model) {
		String userId = (String) sessionObj.getAttribute("userId");
		if (userId == null || (!uservice.findUser(userId).getUserType().equals("Manager"))) {
			return "redirect:/user/login";
		}
		List<LeaveApplication> allrecords = new ArrayList<>();
		allrecords = aservice.findAllByManagerId(userId);
		int len = allrecords.size();
		model.addAttribute("historys", allrecords);
		model.addAttribute("numberofrecords", len);
		model.addAttribute("start", 0);
		model.addAttribute("end", len);
		return "applicationHistoryPageSubordinate";
	}

	@RequestMapping("/subordinatehistorylist/{number}/{start}")
	public String showSubordinateHistoryApplicationsPagination(@PathVariable("number") Integer number,
			@PathVariable("start") Integer start, HttpSession sessionObj, Model model) {
		String userId = (String) sessionObj.getAttribute("userId");

		List<LeaveApplication> allrecords = new ArrayList<>();
		allrecords = aservice.findAllByManagerId(userId);
		int len = allrecords.size();
		List<LeaveApplication> records = new ArrayList<>();
		int end = start + number;
		if (end > len) {
			end = len;
		}
		for (int i = start; i < end; i++) {
			records.add(allrecords.get(i));
		}
		model.addAttribute("historys", records);
		model.addAttribute("numberofrecords", len);
		model.addAttribute("start", start);
		model.addAttribute("end", end);
		return "applicationHistoryPageSubordinate";
	}

	@RequestMapping("/approvelist")
	public String showAllApplicationsPendingforApproval(HttpSession sessionObj, Model model) {
		String userId = (String) sessionObj.getAttribute("userId");
		if (userId == null || (!uservice.findUser(userId).getUserType().equals("Manager"))) {
			return "redirect:/user/login";
		}
		List<LeaveApplication> allrecords = new ArrayList<>();
		allrecords = aservice.findApprovingListByManagerId(userId);
		int len = allrecords.size();
		model.addAttribute("records", allrecords);
		model.addAttribute("numberofrecords", len);
		model.addAttribute("start", 0);
		model.addAttribute("end", len);
		return "approveApplicationPage";
	}

	@RequestMapping("/approvelist/{number}/{start}")
	public String showAllApplicationsPendingforApprovalPagination(@PathVariable("number") Integer number,
			@PathVariable("start") Integer start, HttpSession sessionObj, Model model) {
		String userId = (String) sessionObj.getAttribute("userId");
		if (userId == null || (!uservice.findUser(userId).getUserType().equals("Manager"))) {
			return "redirect:/user/login";
		}
		List<LeaveApplication> allrecords = new ArrayList<>();
		allrecords = aservice.findApprovingListByManagerId(userId);
		int len = allrecords.size();
		List<LeaveApplication> records = new ArrayList<>();
		int end = start + number;
		if (end > len) {
			end = len;
		}
		for (int i = start; i < end; i++) {
			records.add(allrecords.get(i));
		}
		model.addAttribute("records", records);
		model.addAttribute("numberofrecords", len);
		model.addAttribute("start", start);
		model.addAttribute("end", end);

		return "approveApplicationPage";
	}

	@RequestMapping("/detail/employee/{id}")
	public String showapplicationdetailforemployee(@PathVariable("id") Integer id, HttpSession sessionObj,
			Model model) {
		String userId = (String) sessionObj.getAttribute("userId");
		if (userId == null) {
			return "redirect:/user/login";
		}
		model.addAttribute("leaveapplication", aservice.findById(id));
		return "applicationDetailPageEmployee";
	}

	@RequestMapping("/detail/manager/{id}")
	public String showapplicationdetailformanager(@PathVariable("id") Integer id, HttpSession sessionObj, Model model) {
		String userId = (String) sessionObj.getAttribute("userId");
		if (userId == null || (!uservice.findUser(userId).getUserType().equals("Manager"))) {
			return "redirect:/user/login";
		}

		LeaveApplication application = aservice.findById(id);
		model.addAttribute("leaveapplication", application);
		LocalDate start = application.getStartDate();
		LocalDate end = application.getEndDate();
		List<LeaveApplication> otherInPeriod = new ArrayList<>();
		otherInPeriod = aservice.findOtherByStartAndEnd(start, end, id);
		model.addAttribute("historys", otherInPeriod);
		return "applicationDetailPageManager";
	}

	@RequestMapping("/update/{id}")
	public String editApplication(@PathVariable("id") Integer id, HttpSession sessionObj, Model model) {
		String userId = (String) sessionObj.getAttribute("userId");
		if (userId == null) {
			return "redirect:/user/login";
		}
		LeaveApplication application = aservice.findById(id);
		model.addAttribute("leaveapplication", application);
		return "updateApplicationPage";
	}

	@RequestMapping("/delete/{id}")
	public String deleteApplication(@PathVariable("id") Integer id, HttpSession sessionObj, Model model) {
		String userId = (String) sessionObj.getAttribute("userId");
		if (userId == null) {
			return "redirect:/user/login";
		}

		LeaveApplication application = aservice.findById(id);
		aservice.deleteApplication(application);
		return "redirect:/application/historylist";
	}

	@RequestMapping("/approve/{id}")
	public String approveapplication(@PathVariable("id") Integer id, HttpSession sessionObj, Model model) {
		String userId = (String) sessionObj.getAttribute("userId");
		if (userId == null || (!uservice.findUser(userId).getUserType().equals("Manager"))) {
			return "redirect:/user/login";
		}

		LeaveApplication application = aservice.findById(id);
		// approve
		aservice.approveApplication(application);
		// e-mail
		String recipientEmail = application.getUser().getEmailAddress();
		String LeaveState = application.getState();
		eservice.sendEmailToEmployee(recipientEmail, LeaveState);
		return "redirect:/application/approvelist";
	}

	@RequestMapping("/reject/{id}")
	public String rejectapplication(@PathVariable("id") Integer id, @RequestParam("rejectComment") String rejectReason,
			HttpSession sessionObj, Model model) {
		String userId = (String) sessionObj.getAttribute("userId");
		if (userId == null || (!uservice.findUser(userId).getUserType().equals("Manager"))) {
			return "redirect:/user/login";
		}

		LeaveApplication application = aservice.findById(id);
		// reject
		aservice.rejectApplication(application, rejectReason);
		// e-mail
		String recipientEmail = application.getUser().getEmailAddress();
		String LeaveState = application.getState();
		eservice.sendEmailToEmployee(recipientEmail, LeaveState);
		return "redirect:/application/approvelist";
	}

	@RequestMapping("/cancel/{id}")
	public String cancelapplication(@PathVariable("id") Integer id, HttpSession sessionObj, Model model) {
		String userId = (String) sessionObj.getAttribute("userId");
		if (userId == null) {
			return "redirect:/user/login";
		}
		LeaveApplication application = aservice.findById(id);
		aservice.cancelApplication(application);
		return "redirect:/application/historylist";
	}

	@RequestMapping("/update")
	public String updateApplication(@ModelAttribute("application") @Valid LeaveApplication application,
			BindingResult bindingResult, Model model, HttpSession sessionObj) {
		String userId = (String) sessionObj.getAttribute("userId");
		if (userId == null) {
			return "redirect:/user/login";
		}
		if (bindingResult.hasErrors()) {
			return "editApplicationForm";
		}
		LocalDate startDate = application.getStartDate();
		LocalDate endDate = application.getEndDate();
		String leaveType = application.getApplicationLeaveType();
		long daysDifference = ChronoUnit.DAYS.between(startDate, endDate);
		int leavePeriod = (int) daysDifference + 1;
		if (leavePeriod >= 14) {
			long weekends = 0;
			LocalDate date = startDate;
			while (!date.isAfter(endDate)) {
				if (date.getDayOfWeek() == DayOfWeek.SATURDAY || date.getDayOfWeek() == DayOfWeek.SUNDAY) {
					weekends++;
				}
				date = date.plusDays(1);
			}
			long workingDaysDifference = daysDifference + 1 - weekends;
			int holiday = hservice.countHolidayBetween(startDate, endDate);
			leavePeriod = (int) workingDaysDifference - holiday;
		}
		if (leavePeriod > 0) {
			if (leavePeriod > uservice.findLeaveLeft(userId, leaveType)) {
				sessionObj.setAttribute("wrongmessage", "You don't have enough leaves!");
				return "redirect:/application/update/" + application.getApplicationId();
			}
			aservice.updateApplication(application);
			return "redirect:/application/historylist";
		}
		sessionObj.setAttribute("wrongmessage", "Wrong Leave Period, please enter right dates!");
		return "redirect:/application/update/" + application.getApplicationId();
	}

	@RequestMapping("/userreport")
	public String getUserReportPage(Model model, HttpSession sessionObj) {
		String userId = (String) sessionObj.getAttribute("userId");
		if (userId == null || (!uservice.findUser(userId).getUserType().equals("Manager"))) {
			return "redirect:/user/login";
		}
		return "downloadUserReportPage";
	}

	@RequestMapping("/userreport/{start}/{end}/{leaveType}")
	public String SearchUser(@PathVariable("start") LocalDate startDate, @PathVariable("end") LocalDate endDate,
			@PathVariable("leaveType") String leaveType, Model model, HttpSession sessionObj) {
		String userId = (String) sessionObj.getAttribute("userId");
		if (userId == null || (!uservice.findUser(userId).getUserType().equals("Manager"))) {
			return "redirect:/user/login";
		}
		List<User> records = new ArrayList<>();
		if (leaveType.equals("All")) {
			records = aservice.findDistinctUserByStartAndEnd(startDate, endDate);
		} else if (!leaveType.equals("All")) {
			records = aservice.findDistinctUserByStartAndEndAndLeaveType(startDate, endDate, leaveType);
		}
		model.addAttribute("records", records);
		return "downloadUserReportPage";
	}

	@RequestMapping("/leavereport")
	public String getLeaveReortPage(Model model, HttpSession sessionObj) {
		String userId = (String) sessionObj.getAttribute("userId");
		if (userId == null || (!uservice.findUser(userId).getUserType().equals("Manager"))) {
			return "redirect:/user/login";
		}
		return "downloadLeaveReportPage";
	}

	@RequestMapping("/leavereport/{start}/{end}/{leaveType}/{userId}")
	public String SearchApplication(@PathVariable("start") LocalDate startDate, @PathVariable("end") LocalDate endDate,
			@PathVariable("leaveType") String leaveType, @PathVariable("userId") String userId, Model model, HttpSession sessionObj) {
		String userIdInSession = (String) sessionObj.getAttribute("userId");
		if (userIdInSession == null || (!uservice.findUser(userIdInSession).getUserType().equals("Manager"))) {
			return "redirect:/user/login";
		}
		List<LeaveApplication> records = new ArrayList<>();
		if (leaveType.equals("All") && userId.equals("All")) {
			records = aservice.findAllByStartAndEnd(startDate, endDate);
		} else if (leaveType.equals("All") && (!userId.equals("All"))) {
			records = aservice.findAllByStartAndEndAndUserId(startDate, endDate, userId);
		} else if (!leaveType.equals("All") && (userId.equals("All"))) {
			records = aservice.findAllByStartAndEndAndLeaveType(startDate, endDate, leaveType);
		} else if ((!leaveType.equals("All")) && (!userId.equals("All"))) {
			records = aservice.findAllByStartAndEndAndUserIdAndLeaveType(startDate, endDate, userId, leaveType);
		}
		model.addAttribute("records", records);
		return "downloadLeaveReportPage";
	}
}
