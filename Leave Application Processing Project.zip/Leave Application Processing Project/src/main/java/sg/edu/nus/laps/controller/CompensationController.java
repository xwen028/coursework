package sg.edu.nus.laps.controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import sg.edu.nus.laps.interfacemethods.CompensationInterface;
import sg.edu.nus.laps.interfacemethods.UserInterface;
import sg.edu.nus.laps.model.CompensationClaim;
import sg.edu.nus.laps.model.User;
import sg.edu.nus.laps.service.CompensationImplementation;

@Controller
@RequestMapping("/compensation")
public class CompensationController {
	@Autowired
	private CompensationInterface cservice;

	@Autowired
	private UserInterface uservice;

	@Autowired
	public void setProductService(CompensationImplementation cserviceImpl) {
		this.cservice = cserviceImpl;
	}

	@RequestMapping("/create")
	public String createClaim(@RequestParam("startTime") LocalDateTime startTime,
			@RequestParam("endTime") LocalDateTime endTime, HttpSession sessionObj) {
		String userId = (String) sessionObj.getAttribute("userId");
		if (userId == null) {
			return "redirect:/user/login";
		}
		User user = uservice.findUser(userId);
		cservice.createClaim(startTime, endTime, user);
		return "redirect:/user/dashboard";
	}

	@RequestMapping("/historylist")
	public String showHistoryClaim(HttpSession sessionObj, Model model) {
		String userId = (String) sessionObj.getAttribute("userId");
		if (userId == null) {
			return "redirect:/user/login";
		}
		List<CompensationClaim> allrecords = cservice.showAllHistoryClaims(userId);
		int len = allrecords.size();
		model.addAttribute("historys", allrecords);
		model.addAttribute("numberofrecords", len);
		model.addAttribute("start", 0);
		model.addAttribute("end", len);
		return "claimHistoryPage";
	}

	@RequestMapping("/historylist/{number}/{start}")
	public String showHistoryClaimPagination(@PathVariable("number") Integer number,
			@PathVariable("start") Integer start, HttpSession sessionObj, Model model) {
		String userId = (String) sessionObj.getAttribute("userId");
		if (userId == null) {
			return "redirect:/user/login";
		}
		List<CompensationClaim> allrecords = new ArrayList<>();
		allrecords = cservice.showAllHistoryClaims(userId);
		int len = allrecords.size();
		List<CompensationClaim> records = new ArrayList<>();
		int end = start + number;
		if (end > len) {
			end = len;
		}
		for (int i = start; i < end; i++) {
			records.add(allrecords.get(i));
		}
		model.addAttribute("historys", records);
		model.addAttribute("numberofrecords", len);
		model.addAttribute("start", start);
		model.addAttribute("end", end);
		return "claimHistoryPage";
	}

	@RequestMapping("/update/{id}")
	public String editApplication(@PathVariable("id") Integer id, Model model, HttpSession sessionObj) {
		String userId = (String) sessionObj.getAttribute("userId");
		if (userId == null) {
			return "redirect:/user/login";
		}
		model.addAttribute("compensationClaim", cservice.findCompensationClaimById(id));
		return "updateClaimPage";
	}

	@RequestMapping("/update")
	public String updateProduct(@ModelAttribute("compensationClaim") @Valid CompensationClaim compensationClaim,
			BindingResult bindingResult, Model model, HttpSession sessionObj) {
		if (bindingResult.hasErrors()) {
			return "updateClaimPage";
		}
		String userId = (String) sessionObj.getAttribute("userId");
		if (userId == null) {
			return "redirect:/user/login";
		}
		cservice.updateClaim(compensationClaim);
		return "redirect:/compensation/historylist";
	}

	@RequestMapping("/delete/{id}")
	public String deleteApplication(@PathVariable("id") Integer id, Model model, HttpSession sessionObj) {
		String userId = (String) sessionObj.getAttribute("userId");
		if (userId == null) {
			return "redirect:/user/login";
		}
		CompensationClaim claim = cservice.findCompensationClaimById(id);
		cservice.deleteClaim(claim);
		return "redirect:/compensation/historylist";
	}

	@RequestMapping("/approve/{id}")
	public String approveapplication(@PathVariable("id") Integer id, Model model, HttpSession sessionObj) {
		String userId = (String) sessionObj.getAttribute("userId");
		if (userId == null || (!uservice.findUser(userId).getUserType().equals("Manager"))) {
			return "redirect:/user/login";
		}
		CompensationClaim claim = cservice.findCompensationClaimById(id);
		cservice.approveClaim(claim);
		return "redirect:/compensation/approvelist";
	}

	@RequestMapping("/reject/{id}")
	public String rejectapplication(@PathVariable("id") Integer id, @RequestParam("rejectComment") String rejectReason,
			Model model, HttpSession sessionObj) {
		String userId = (String) sessionObj.getAttribute("userId");
		if (userId == null || (!uservice.findUser(userId).getUserType().equals("Manager"))) {
			return "redirect:/user/login";
		}
		CompensationClaim claim = cservice.findCompensationClaimById(id);
		cservice.rejectClaim(claim, rejectReason);
		model.addAttribute("claim", claim);
		return "redirect:/compensation/approvelist";
	}

	@RequestMapping("/approvelist")
	public String showClaimApprovalList(HttpSession sessionObj, Model model) {
		String userId = (String) sessionObj.getAttribute("userId");
		if (userId == null || (!uservice.findUser(userId).getUserType().equals("Manager"))) {
			return "redirect:/user/login";
		}
		List<CompensationClaim> allrecords = cservice.findClaimPendingForApproving(userId);
		int len = allrecords.size();
		model.addAttribute("records", allrecords);
		model.addAttribute("numberofrecords", len);
		model.addAttribute("start", 0);
		model.addAttribute("end", len);
		return "approveClaimPage";
	}

	@RequestMapping("/approvelist/{number}/{start}")
	public String showClaimApprovalListPagination(@PathVariable("number") Integer number,
			@PathVariable("start") Integer start, HttpSession sessionObj, Model model) {
		String userId = (String) sessionObj.getAttribute("userId");
		if (userId == null || (!uservice.findUser(userId).getUserType().equals("Manager"))) {
			return "redirect:/user/login";
		}
		List<CompensationClaim> allrecords = new ArrayList<>();
		allrecords = cservice.findClaimPendingForApproving(userId);
		int len = allrecords.size();
		List<CompensationClaim> records = new ArrayList<>();
		int end = start + number;
		if (end > len) {
			end = len;
		}
		for (int i = start; i < end; i++) {
			records.add(allrecords.get(i));
		}
		model.addAttribute("records", records);
		model.addAttribute("numberofrecords", len);
		model.addAttribute("start", start);
		model.addAttribute("end", end);

		return "approveClaimPage";
	}

	@RequestMapping("/claimreport")
	public String getUserReportPage(Model model, HttpSession sessionObj) {
		String userId = (String) sessionObj.getAttribute("userId");
		if (userId == null || (!uservice.findUser(userId).getUserType().equals("Manager"))) {
			return "redirect:/user/login";
		}
		return "downloadClaimReportPage";
	}

	@RequestMapping("/claimreport/{start}/{end}/{userId}/{claimState}")
	public String SearchUser(@PathVariable("start") LocalDateTime startDate, @PathVariable("end") LocalDateTime endDate,
			@PathVariable("userId") String userId, @PathVariable("claimState") String claimState, Model model, HttpSession sessionObj) {
		String userIdInsession = (String) sessionObj.getAttribute("userId");
		if (userId == null || (!uservice.findUser(userIdInsession).getUserType().equals("Manager"))) {
			return "redirect:/user/login";
		}
		List<CompensationClaim> records = new ArrayList<>();
		if (userId.equals("All") && claimState.equals("All")) {
			records = cservice.findAllByStartAndEnd(startDate, endDate);
		} else if (userId.equals("All") && claimState.equals("AppliedOrUpdated")) {
			records = cservice.findAllByStartAndEndPendingForApproval(startDate, endDate);
		} else if (userId.equals("All") && (claimState.equals("Approved") || claimState.equals("Rejected"))) {
			records = cservice.findAllByStartAndEndAndState(startDate, endDate, claimState);
		} else if (!userId.equals("All") && claimState.equals("All")) {
			records = cservice.findAllByStartAndEndAndUserId(startDate, endDate, userId);
		} else if (!userId.equals("All") && claimState.equals("AppliedOrUpdated")) {
			records = cservice.findAllByStartAndEndAndUserIdPendingForApproval(startDate, endDate, userId);
		} else if (!userId.equals("All") && (claimState.equals("Approved") || claimState.equals("Rejected"))) {
			records = cservice.findAllByStartAndEndAndUserIdAndState(startDate, endDate, userId, claimState);
		}

		model.addAttribute("records", records);
		return "downloadClaimReportPage";
	}

}
