package sg.edu.nus.laps.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import jakarta.servlet.http.HttpServletResponse;
import sg.edu.nus.laps.model.CompensationClaim;
import sg.edu.nus.laps.model.LeaveApplication;
import sg.edu.nus.laps.model.User;
import sg.edu.nus.laps.service.ApplicationImplementation;
import sg.edu.nus.laps.service.CompensationImplementation;
import sg.edu.nus.laps.service.CsvService;

@Controller
public class DownloadController {

	@Autowired
	private CsvService csvService;
	@Autowired
	private ApplicationImplementation aservice;
	@Autowired
	private CompensationImplementation cservice;

	@GetMapping("/download-csv/application/{start}/{end}/{leaveType}/{userId}")
	public void downloadLeavesByPeriodAndTypeAndUserId(HttpServletResponse response, @PathVariable("start") LocalDate startDate,
			@PathVariable("end") LocalDate endDate, @PathVariable("leaveType") String leaveType,
			@PathVariable("userId") String userId, Model model) {
		List<LeaveApplication> dataList = new ArrayList<>();
		if (leaveType.equals("All") && userId.equals("All")) {
			dataList  = aservice.findAllByStartAndEnd(startDate, endDate);
		} else if (leaveType.equals("All") && (!userId.equals("All"))) {
			dataList  = aservice.findAllByStartAndEndAndUserId(startDate, endDate, userId);
		} else if (!leaveType.equals("All") && (userId.equals("All"))) {
			dataList  = aservice.findAllByStartAndEndAndLeaveType(startDate, endDate, leaveType);
		} else if (!leaveType.equals("All") && (!userId.equals("All"))) {
			dataList  = aservice.findAllByStartAndEndAndUserIdAndLeaveType(startDate, endDate, userId, leaveType);
		}
		try {
			String fileName = "output"; // 指定文件名（不含扩展名）
			// 生成 CSV 文件
			csvService.generateCsv(dataList, fileName);

			// 设置响应头
			response.setContentType("text/csv");
			response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + ".csv\"");

			// 读取生成的 CSV 文件并写入响应流
			FileInputStream fileInputStream = new FileInputStream(fileName + ".csv");
			IOUtils.copy(fileInputStream, response.getOutputStream());
			response.flushBuffer();
			fileInputStream.close();
		} catch (IOException e) {
			e.printStackTrace();
			// 处理异常
		}
	}
	
	
	@GetMapping("/download-csv/user/{start}/{end}/{leaveType}")
	public void downloadUsersOnLeaveByPeriod(HttpServletResponse response, @PathVariable("start") LocalDate startDate,
			@PathVariable("end") LocalDate endDate, @PathVariable("leaveType") String leaveType, Model model) {
		List<User> dataList = new ArrayList<>();
		if(leaveType.equals("All")) {
			dataList = aservice.findDistinctUserByStartAndEnd(startDate,endDate);
		}
		else if(!leaveType.equals("All")) {
			dataList = aservice.findDistinctUserByStartAndEndAndLeaveType(startDate,endDate,leaveType);
		}
		try {
			String fileName = "output"; // 指定文件名（不含扩展名）
			// 生成 CSV 文件
			csvService.generateCsv(dataList, fileName);

			// 设置响应头
			response.setContentType("text/csv");
			response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + ".csv\"");

			// 读取生成的 CSV 文件并写入响应流
			FileInputStream fileInputStream = new FileInputStream(fileName + ".csv");
			IOUtils.copy(fileInputStream, response.getOutputStream());
			response.flushBuffer();
			fileInputStream.close();
		} catch (IOException e) {
			e.printStackTrace();
			// 处理异常
		}
	}

	@GetMapping("/download-csv/claim/{start}/{end}/{userId}/{claimState}")
	public void downloadLeavesByUserId(HttpServletResponse response,@PathVariable("start") LocalDateTime startDate,
			@PathVariable("end") LocalDateTime endDate, @PathVariable("userId") String userId, @PathVariable("claimState") String claimState,Model model) {
		try {
			List<CompensationClaim> dataList = new ArrayList<>();
			if(userId.equals("All")&&claimState.equals("All")) {
				dataList = cservice.findAllByStartAndEnd(startDate,endDate);
			}
			else if(userId.equals("All")&&claimState.equals("AppliedOrUpdated")) {
				dataList = cservice.findAllByStartAndEndPendingForApproval(startDate,endDate);
			}
			else if(userId.equals("All")&&(claimState.equals("Approved")||claimState.equals("Rejected"))) {
				dataList = cservice.findAllByStartAndEndAndState(startDate,endDate,claimState);
			}
			else if(!userId.equals("All")&&claimState.equals("All")){
				dataList = cservice.findAllByStartAndEndAndUserId(startDate,endDate,userId);
			}
			else if(!userId.equals("All")&&claimState.equals("AppliedOrUpdated")) {
				dataList = cservice.findAllByStartAndEndAndUserIdPendingForApproval(startDate,endDate,userId);
			}
			else if(!userId.equals("All")&&(claimState.equals("Approved")||claimState.equals("Rejected"))) {
				dataList = cservice.findAllByStartAndEndAndUserIdAndState(startDate,endDate,userId,claimState);
			}
			String fileName = "output"; // 指定文件名（不含扩展名）
			// 生成 CSV 文件
			csvService.generateCsv(dataList, fileName);

			// 设置响应头
			response.setContentType("text/csv");
			response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + ".csv\"");

			// 读取生成的 CSV 文件并写入响应流
			FileInputStream fileInputStream = new FileInputStream(fileName + ".csv");
			IOUtils.copy(fileInputStream, response.getOutputStream());
			response.flushBuffer();
			fileInputStream.close();
		} catch (IOException e) {
			e.printStackTrace();
			// 处理异常
		}
	}
}
