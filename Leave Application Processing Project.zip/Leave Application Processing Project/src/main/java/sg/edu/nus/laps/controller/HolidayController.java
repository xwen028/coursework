package sg.edu.nus.laps.controller;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import sg.edu.nus.laps.interfacemethods.HolidayInterface;
import sg.edu.nus.laps.interfacemethods.UserInterface;
import sg.edu.nus.laps.model.PublicHoliday;
import sg.edu.nus.laps.service.HolidayImplementation;
import sg.edu.nus.laps.service.UserImplementation;

@Controller
@RequestMapping("/holiday")
public class HolidayController {
	@Autowired
	private HolidayInterface hservice;
	private UserInterface uservice;

	@Autowired
	public void setProductService(HolidayImplementation hserviceImpl, UserImplementation userviceImpl) {
		this.hservice = hserviceImpl;
		this.uservice = userviceImpl;
	}

	@RequestMapping("/create")
	public String createHoliday(@RequestParam("holidayStartDate") LocalDate holidayStartDate,
			@RequestParam("holidayEndDate") LocalDate holidayEndDate, @RequestParam("description") String description,
			HttpSession sessionObj) {
		String userId = (String) sessionObj.getAttribute("userId");
		if (userId == null || (!uservice.findUser(userId).getUserType().equals("Admin"))) {
			return "redirect:/user/login";
		}
		hservice.createHoliday(holidayStartDate, holidayEndDate, description);
		return "redirect:/user/showallholidays";
	}

	@RequestMapping("/update/{id}")
	public String editHoliday(@PathVariable("id") int id, Model model, HttpSession sessionObj) {
		String userId = (String) sessionObj.getAttribute("userId");
		if (userId == null || (!uservice.findUser(userId).getUserType().equals("Admin"))) {
			return "redirect:/user/login";
		}
		model.addAttribute("holiday", hservice.findHoliday(id));
		return "updateHolidayPage";
	}

	@RequestMapping("/update")
	public String updateHoliday(@ModelAttribute("publicholiday") @Valid PublicHoliday publicholiday,
			BindingResult bindingResult, Model model, HttpSession sessionObj) {
		if (bindingResult.hasErrors()) {
			return "updateHolidayPage";
		}
		String userId = (String) sessionObj.getAttribute("userId");
		if (userId == null || (!uservice.findUser(userId).getUserType().equals("Admin"))) {
			return "redirect:/user/login";
		}
		hservice.updateHoliday(publicholiday);
		return "redirect:/user/showallholidays";
	}
}
