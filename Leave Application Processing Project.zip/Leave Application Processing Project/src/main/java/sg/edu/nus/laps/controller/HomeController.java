package sg.edu.nus.laps.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import jakarta.servlet.http.HttpSession;
import sg.edu.nus.laps.interfacemethods.UserInterface;
import sg.edu.nus.laps.service.UserImplementation;

@Controller
public class HomeController {
	@Autowired
	private UserInterface uservice;

	@Autowired
	public void setProductService(UserImplementation userviceImpl) {
		this.uservice = userviceImpl;
	}
	@RequestMapping("/")
	public String getUserDashboard(HttpSession sessionObj) {
		if ((String) sessionObj.getAttribute("userId") != null) {
			String userId = (String) sessionObj.getAttribute("userId");
			String userType = uservice.getType(userId);
			switch (userType) {
			case "Employee":
				return "employeeDashboard";
			case "Manager":
				return "managerDashboard";
			case "Admin":
				return "adminDashboard";
			default:
				return "userDashboard";
			}
		}
		return "userDashboard";
	}
}
