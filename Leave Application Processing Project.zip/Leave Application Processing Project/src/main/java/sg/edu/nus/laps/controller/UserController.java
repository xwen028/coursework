package sg.edu.nus.laps.controller;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import sg.edu.nus.laps.interfacemethods.ApplicationInterface;
import sg.edu.nus.laps.interfacemethods.HolidayInterface;
import sg.edu.nus.laps.interfacemethods.UserInterface;
import sg.edu.nus.laps.model.LeaveApplication;
import sg.edu.nus.laps.model.PublicHoliday;
import sg.edu.nus.laps.model.User;
import sg.edu.nus.laps.service.ApplicationImplementation;
import sg.edu.nus.laps.service.HolidayImplementation;
import sg.edu.nus.laps.service.UserImplementation;

@Controller
@RequestMapping("/user")
public class UserController {
	@Autowired
	private UserInterface uservice;
	@Autowired
	private HolidayInterface hservice;
	@Autowired
	private ApplicationInterface aservice;

	@Autowired
	public void setProductService(UserImplementation userviceImpl, HolidayImplementation hserviceImpl,
			ApplicationImplementation aserviceImpl) {
		this.uservice = userviceImpl;
		this.hservice = hserviceImpl;
		this.aservice = aserviceImpl;
	}

	@RequestMapping("/login")
	public String getloginPage() {
		return "redirect:/user/login/nonuser/nonpass";
	}

	@RequestMapping("/login/{id}/{pass}")
	public String getDashboardPage(@PathVariable("id") String userId, @PathVariable("pass") String password,
			HttpSession sessionObj) {
		if ((String) sessionObj.getAttribute("userId") != null) {
			userId = (String) sessionObj.getAttribute("userId");
			return "redirect:/user/dashboard/" + userId;
		}
		if (uservice.Vertify(userId, password)) {
			sessionObj.setAttribute("userId", userId);
			sessionObj.removeAttribute("wrongmessage");
			return "redirect:/user/dashboard/" + userId;
		}
		if (!(userId.equals("nonuser") && password.equals("nonpass"))) {
			sessionObj.setAttribute("wrongmessage", " Wrong UserId or Password");
		}
		return "loginPage";
	}

	@RequestMapping("/dashboard")
	public String showdashboard(HttpSession sessionObj) {
		if ((String) sessionObj.getAttribute("userId") == null) {
			return "redirect:/user/login";
		}
		String userId = (String) sessionObj.getAttribute("userId");
		return "redirect:/user/dashboard/" + userId;
	}

	@RequestMapping("/dashboard/{id}")
	public String showdashboardwithid(@PathVariable("id") String userId, HttpSession sessionObj) {
		if ((String) sessionObj.getAttribute("userId") == null) {
			return "redirect:/user/login/nonuser/nonpass";
		}
		String userType = uservice.getType(userId);
		switch (userType) {
		case "Employee":
			return "employeeDashboard";
		case "Manager":
			return "managerDashboard";
		case "Admin":
			return "adminDashboard";
		default:
			return "userDashboard";
		}
	}

	@RequestMapping("/logout")
	public String logout(HttpSession sessionObj) {
		sessionObj.removeAttribute("userId");
		return "redirect:/";
	}

	@RequestMapping("/createuser")
	public String getCreateUserPage(Model model, HttpSession sessionObj) {
		if ((String) sessionObj.getAttribute("userId") == null) {
			return "redirect:/user/login/nonuser/nonpass";
		}
		User newuser = new User();
		model.addAttribute("user", newuser);
		return "createUserPage";
	}

	@RequestMapping("/createholiday")
	public String getCreateHolidayPage(HttpSession sessionObj) {
		if ((String) sessionObj.getAttribute("userId") == null) {
			return "redirect:/user/login/nonuser/nonpass";
		}
		return "createHolidayPage";
	}

	@RequestMapping("/showallusers")
	public String getUserListPage(Model model, HttpSession sessionObj) {
		if ((String) sessionObj.getAttribute("userId") == null) {
			return "redirect:/user/login/nonuser/nonpass";
		}
		model.addAttribute("users", uservice.showAllUsers());
		return "userListPage";
	}

	@RequestMapping("/showallholidays")
	public String getHolidayListPage(Model model, HttpSession sessionObj) {
		if ((String) sessionObj.getAttribute("userId") == null) {
			return "redirect:/user/login/nonuser/nonpass";
		}
		model.addAttribute("holidays", hservice.showAllHolidays());
		return "holidayListPage";
	}

	@RequestMapping("/update/{id}")
	public String getUpdateUserPage(@PathVariable("id") String useId, Model model, HttpSession sessionObj) {
		if ((String) sessionObj.getAttribute("userId") == null) {
			return "redirect:/user/login/nonuser/nonpass";
		}
		User usertoupdate = uservice.findUser(useId);
		model.addAttribute("user", usertoupdate);
		return "updateUserPage";
	}

	@RequestMapping("/delete/{id}")
	public String deleteUser(@PathVariable("id") String useId, Model model, HttpSession sessionObj) {
		if ((String) sessionObj.getAttribute("userId") == null) {
			return "redirect:/user/login/nonuser/nonpass";
		}
		User usertodelete = uservice.findUser(useId);
		uservice.deleteUser(usertodelete);
		return "redirect:/user/showallusers";
	}
	/*
	 * @RequestMapping("/create") public String createUser(@RequestParam("userId")
	 * String userId, @RequestParam("password") String password,
	 * 
	 * @RequestParam("userType") String userType, @RequestParam("managerId") String
	 * managerId,
	 * 
	 * @RequestParam("emailAddress") String emailAddress) {
	 * uservice.createUser(userId, password, userType, managerId, emailAddress);
	 * return "redirect:/user/login"; }
	 */

	@RequestMapping("/create")
	public String createUser(@ModelAttribute("User") @Valid User user, BindingResult bindingResult, Model model,HttpSession sessionObj) {
		if (bindingResult.hasErrors()) {
			String errorMessage = bindingResult.getFieldError().getDefaultMessage();
			sessionObj.setAttribute("error", errorMessage);
			return "redirect:/user/createuser";
		}
		sessionObj.removeAttribute("error");
		uservice.createUser(user);
		return "redirect:/user/showallusers";
	}

	@RequestMapping("/information")
	public String getImformationPage(HttpSession sessionObj, Model model) {
		String userId = (String) sessionObj.getAttribute("userId");
		if (userId == null) {
			return "redirect:/user/login/nonuser/nonpass";
		}
		User user = uservice.findUser(userId);
		model.addAttribute("user", user);
		return "userInformationPage";
	}

	@RequestMapping("/update")
	public String updateUser(@ModelAttribute("User") @Valid User user, BindingResult bindingResult, Model model,HttpSession sessionObj) {
		if (bindingResult.hasErrors()) {
			String errorMessage = bindingResult.getFieldError().getDefaultMessage();
			sessionObj.setAttribute("error", errorMessage);
			return "redirect:/user/createuser";
		}
		uservice.updateUser(user);
		return "redirect:/user/showallusers";
	}

	@RequestMapping("/createapplication")
	public String getCreateApplicationPage(HttpSession sessionObj) {
		if ((String) sessionObj.getAttribute("userId") == null) {
			return "redirect:/user/login/nonuser/nonpass";
		}
		return "createApplicationPage";

	}

	@RequestMapping("/claimcompensation")
	public String getClaimCompensationPage(HttpSession sessionObj) {
		if ((String) sessionObj.getAttribute("userId") == null) {
			return "redirect:/user/login";
		}
		return "claimCompensationPage";
	}

	@RequestMapping("/updateholiday/{id}")
	public String getUpdateHolidayPage(@PathVariable("id") int id, Model model, HttpSession sessionObj) {
		if ((String) sessionObj.getAttribute("userId") == null) {
			return "redirect:/user/login";
		}
		PublicHoliday holidaytoupdate = hservice.findHoliday(id);
		model.addAttribute("holiday", holidaytoupdate);
		return "updateHolidayPage";
	}

	@RequestMapping("/deleteholiday/{id}")
	public String getDeleteHolidayPage(@PathVariable("id") int id, Model model, HttpSession sessionObj) {
		if ((String) sessionObj.getAttribute("userId") == null) {
			return "redirect:/user/login";
		}
		PublicHoliday holidaytodelete = hservice.findHoliday(id);
		hservice.deleteHoliday(holidaytodelete);
		return "redirect:/user/showallholidays";
	}

	@RequestMapping("/movementregister")
	public String getMonth() {
		Calendar calendar = Calendar.getInstance();
		int currentYear = calendar.get(Calendar.YEAR);
		int currentMonth = calendar.get(Calendar.MONTH) + 1;
		return "redirect:/user/movementregister/" + currentYear + "/" + currentMonth;
	}

	@RequestMapping("/movementregister/{year}/{month}")
	public String getMovementRegisterPage(@PathVariable("year") int year, @PathVariable("month") int month,
			Model model) {
		if (month == 13) {
			year = year + 1;
			month = 1;
		}
		if (month == 0) {
			year = year - 1;
			month = 12;
		}
		List<LeaveApplication> leavelist = aservice.findAllByYearAndMonth(year, month);
		Map<User, List<String>> userlist = new HashMap<>();
		for (LeaveApplication l : leavelist) {
			User user = l.getUser();
			if (userlist.containsKey(user)) {
				if (!userlist.get(user).contains(l.getApplicationLeaveType())) {
					List<String> newlist = userlist.get(user);
					newlist.add(l.getApplicationLeaveType());
					userlist.put(user, newlist);
				}
			} else {
				List<String> newlist = new ArrayList<>();
				newlist.add(l.getApplicationLeaveType());
				userlist.put(user, newlist);
			}
		}
		model.addAttribute("users", userlist);
		model.addAttribute("year", year);
		model.addAttribute("month", month);

		return "movementRegisterPage";
	}

	@RequestMapping("/generatereport")
	public String getChooseReportTypePage(HttpSession sessionObj) {
		if ((String) sessionObj.getAttribute("userId") == null) {
			return "redirect:/user/login";
		}
		return "chooseReportTypePage";
	}
}
