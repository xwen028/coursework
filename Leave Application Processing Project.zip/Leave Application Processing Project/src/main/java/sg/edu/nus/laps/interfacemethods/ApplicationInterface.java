package sg.edu.nus.laps.interfacemethods;

import java.time.LocalDate;
import java.util.List;

import sg.edu.nus.laps.model.LeaveApplication;
import sg.edu.nus.laps.model.User;

public interface ApplicationInterface {
	public List<LeaveApplication> findAllByUserId(String userId);

	public List<LeaveApplication> findAllByManagerId(String managerId);

	public List<LeaveApplication> findApprovingListByManagerId(String managerId);

	public LeaveApplication findById(Integer Id);

	public void createApplication(String leaveType, LocalDate startDate, LocalDate endDate, User user,
			String additionalReason, String workDissemination, String contactDetail, int leavePeriod);

	public boolean updateApplication(LeaveApplication application);

	public boolean deleteApplication(LeaveApplication application);

	public boolean approveApplication(LeaveApplication application);

	public boolean rejectApplication(LeaveApplication application, String rejectComment);

	public boolean cancelApplication(LeaveApplication application);

	public List<LeaveApplication> findOtherByStartAndEnd(LocalDate start, LocalDate end, int applicationId);

	public List<LeaveApplication> findAllByStartAndEnd(LocalDate start, LocalDate end);

	public List<LeaveApplication> findAllByStartAndEndAndUserId(LocalDate start, LocalDate end, String userId);

	public List<LeaveApplication> findAllByStartAndEndAndLeaveType(LocalDate start, LocalDate end, String leaveType);

	public List<LeaveApplication> findAllByStartAndEndAndUserIdAndLeaveType(LocalDate start, LocalDate end,
			String userId, String leaveType);

	public List<LeaveApplication> findAllByYearAndMonth(int year, int month);
	public List<User> findDistinctUserByStartAndEnd(LocalDate startDate,LocalDate endDate);
	public List<User> findDistinctUserByStartAndEndAndLeaveType(LocalDate startDate,LocalDate endDate,String leaveType);
}
