package sg.edu.nus.laps.interfacemethods;

import java.time.LocalDateTime;
import java.util.List;

import sg.edu.nus.laps.model.CompensationClaim;
import sg.edu.nus.laps.model.User;

public interface CompensationInterface {
	public void createClaim(LocalDateTime startTime,LocalDateTime endTime,User user);
	public List<CompensationClaim> showAllHistoryClaims(String userId);
	public CompensationClaim findCompensationClaimById(int id);
	public boolean updateClaim(CompensationClaim claim);
	public boolean deleteClaim(CompensationClaim claim);
	public boolean rejectClaim(CompensationClaim claim,String rejectComment);
	public boolean approveClaim(CompensationClaim claim);
	public List<CompensationClaim> findClaimPendingForApproving(String managerId);
	public List<CompensationClaim> findAllByStartAndEnd(LocalDateTime startDate,LocalDateTime endDate);
	public List<CompensationClaim> findAllByStartAndEndAndUserId(LocalDateTime startDate,LocalDateTime endDate,String UserId);
	public List<CompensationClaim> findAllByStartAndEndPendingForApproval(LocalDateTime startDate,LocalDateTime endDate);
	public List<CompensationClaim> findAllByStartAndEndAndState(LocalDateTime startDate,LocalDateTime endDate,String claimState);
	public List<CompensationClaim> findAllByStartAndEndAndUserIdPendingForApproval(LocalDateTime startDate,LocalDateTime endDate,String userId);
	public List<CompensationClaim> findAllByStartAndEndAndUserIdAndState(LocalDateTime startDate,LocalDateTime endDate,String userId,String claimState);
}
