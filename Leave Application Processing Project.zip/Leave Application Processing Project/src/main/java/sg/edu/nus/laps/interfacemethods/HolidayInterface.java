package sg.edu.nus.laps.interfacemethods;

import java.time.LocalDate;
import java.util.List;
import sg.edu.nus.laps.model.PublicHoliday;

public interface HolidayInterface {
	public List<PublicHoliday> showAllHolidays();
	public void createHoliday(LocalDate holidayStartDate,LocalDate holidayEndDate,String description);
	public int countHolidayBetween(LocalDate holidayStartDate, LocalDate holidayEndDate);
	public PublicHoliday findHoliday(int id) ;
	public void updateHoliday(PublicHoliday publicholiday);
	public void deleteHoliday(PublicHoliday publicholiday);
}
