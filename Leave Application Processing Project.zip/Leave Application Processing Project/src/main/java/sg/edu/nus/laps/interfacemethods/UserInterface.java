package sg.edu.nus.laps.interfacemethods;

import java.util.List;

import sg.edu.nus.laps.model.User;

public interface UserInterface {
	public boolean Vertify(String userid, String password);
	public String getType(String userid);
	//public void createUser(String userId,String password,String userType ,String managerId,String emailAddress);
	public boolean createUser(User user);
	public User findUser(String userId);
	public List<User> showAllUsers();
	public void deleteUser(User user);
	public boolean updateUser(User user);
	public int findLeaveLeft(String userId,String leaveType);
}
