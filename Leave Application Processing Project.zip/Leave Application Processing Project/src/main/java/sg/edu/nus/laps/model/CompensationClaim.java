package sg.edu.nus.laps.model;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class CompensationClaim {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int ClaimId;
	@Column
	private LocalDateTime StartTime;
	@Column
	private LocalDateTime EndTime;
	@Column
	private String State;
	@Column
	private String RejectComment;
	@ManyToOne
	private User user;

	public CompensationClaim() {
		this.State = "Applied";
	}

	public int getClaimId() {
		return ClaimId;
	}

	public void setClaimId(int claimId) {
		ClaimId = claimId;
	}

	public LocalDateTime getStartTime() {
		return StartTime;
	}

	public void setStartTime(LocalDateTime startTime) {
		StartTime = startTime;
	}

	public LocalDateTime getEndTime() {
		return EndTime;
	}

	public void setEndTime(LocalDateTime endTime) {
		EndTime = endTime;
	}

	public String getState() {
		return State;
	}

	public void setState(String state) {
		State = state;
	}

	public String getRejectComment() {
		return RejectComment;
	}

	public void setRejectComment(String rejectComment) {
		RejectComment = rejectComment;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
}
