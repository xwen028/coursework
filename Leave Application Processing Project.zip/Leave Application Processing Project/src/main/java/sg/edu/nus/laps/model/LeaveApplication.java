package sg.edu.nus.laps.model;
import java.time.LocalDate;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class LeaveApplication {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int ApplicationId;
	@Column
	private String AdditionalReason;
	@Column
	private String ApplicationLeaveType;
	@Column
	private String WorkDissemination;
	@Column
	private String ContactDetail;
	@Column
	private LocalDate StartDate;
	@Column
	private LocalDate EndDate;
	@Column
	private int LeavePeriod;
	@Column
	private String State;
	@Column
	private String RejectComment;
	@ManyToOne
	private User user;
	public LeaveApplication() {
		this.State = "Applied";
	}
	
	public int getApplicationId() {
		return this.ApplicationId;
	}
	public void setApplicationId(int newApplicationId) {
		this.ApplicationId = newApplicationId;
		return;
	}

	public String getAdditionalReason() {
		return AdditionalReason;
	}

	public void setAdditionalReason(String addtionalReason) {
		AdditionalReason = addtionalReason;
	}

	public String getWorkDissemination() {
		return WorkDissemination;
	}

	public void setWorkDissemination(String workDissemination) {
		WorkDissemination = workDissemination;
	}

	public String getContactDetail() {
		return ContactDetail;
	}

	public void setContactDetail(String contactDetail) {
		ContactDetail = contactDetail;
	}

	public LocalDate getStartDate() {
		return StartDate;
	}

	public void setStartDate(LocalDate startDate) {
		StartDate = startDate;
	}

	public LocalDate getEndDate() {
		return EndDate;
	}

	public void setEndDate(LocalDate endDate) {
		EndDate = endDate;
	}

	public int getLeavePeriod() {
		return LeavePeriod;
	}

	public void setLeavePeriod(int leavePeriod) {
		LeavePeriod = leavePeriod;
	}

	public String getState() {
		return State;
	}

	public void setState(String state) {
		State = state;
	}

	public String getRejectComment() {
		return RejectComment;
	}

	public void setRejectComment(String rejectComment) {
		RejectComment = rejectComment;
	}

	public String getApplicationLeaveType() {
		return ApplicationLeaveType;
	}

	public void setApplicationLeaveType(String applicationLeaveType) {
		ApplicationLeaveType = applicationLeaveType;
	}
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
}