package sg.edu.nus.laps.model;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class PublicHoliday {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int HolidayId;

	@Column
	private LocalDate HolidayDate;
	@Column
	private String Description;

	public PublicHoliday() {
	}

	public LocalDate getHolidayDate() {
		return HolidayDate;
	}

	public void setHolidayDate(LocalDate holidayDate) {
		HolidayDate = holidayDate;
	}

	public String getDescription() {
		return Description;
	}

	public void setDescription(String description) {
		Description = description;
	}
	
	public int getHolidayId() {
		return HolidayId;
	}

	public void setHolidayId(int holidayId) {
		HolidayId = holidayId;
	}
}
