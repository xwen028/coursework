package sg.edu.nus.laps.model;

import java.util.List;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@Entity
public class User {
	@Id
	@Size(min=3, max=20,message = "userId must be 3-20 characters")
	private String UserId;
	@Column
	@Size(min=3,message = "password must be at least 3 characters")
	private String Password;
	@Column
	private int AnnualLeave;
	@Column
	private int MedicalLeave;
	@Column
	private double CompensationLeave;
	@Column
	private String UserType;
	@Column
	@Size(min=3, max=20,message = "managerId must be 3-20 characters")
	private String ManagerId;
	@Column
	@Pattern(regexp = "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$", message = "Invalid email format")
	private String EmailAddress;
	@Column
	private Long OverTimeSeconds;
	@OneToMany(mappedBy = "user")
	private List<LeaveApplication> leaveapplicationlist;
	@OneToMany(mappedBy = "user")
	private List<CompensationClaim> compensationclaimlist;

	public User() {
		AnnualLeave = 0;
		MedicalLeave = 0;
		CompensationLeave = 0;
		OverTimeSeconds = 0l;
		ManagerId ="None";
	}

	public String getUserId() {
		return this.UserId;
	}

	public void setUserId(String newUserId) {
		this.UserId = newUserId;
		return;
	}

	public String getPassword() {
		return this.Password;
	}

	public void setPassword(String newPassword) {
		this.Password = newPassword;
		return;
	}

	public int getAnnualLeave() {
		return this.AnnualLeave;
	}

	public void setAnnualLeave(int newValue) {
		this.AnnualLeave = newValue;
		return;
	}

	public int getMedicalLeave() {
		return this.MedicalLeave;
	}

	public void setMedicalLeave(int newValue) {
		this.MedicalLeave = newValue;
		return;
	}

	public double getCompensationLeave() {
		return this.CompensationLeave;
	}

	public void setCompensationLeave(double newValue) {
		this.CompensationLeave = newValue;
		return;
	}

	public String getUserType() {
		return this.UserType;
	}

	public void setUserType(String newType) {
		this.UserType = newType;
		return;
	}

	public Long getOverTimeSeconds() {
		return OverTimeSeconds;
	}

	public void setOverTimeSeconds(Long overTimeSeconds) {
		OverTimeSeconds = overTimeSeconds;
	}

	public List<LeaveApplication> getLeaveapplicationlist() {
		return leaveapplicationlist;
	}

	public void setLeaveapplicationlist(List<LeaveApplication> leaveapplicationlist) {
		this.leaveapplicationlist = leaveapplicationlist;
	}

	public List<CompensationClaim> getCompensationclaimlist() {
		return compensationclaimlist;
	}

	public void setCompensationclaimlist(List<CompensationClaim> compensationclaimlist) {
		this.compensationclaimlist = compensationclaimlist;
	}

	public String getManagerId() {
		return ManagerId;
	}

	public void setManagerId(String managerId) {
		ManagerId = managerId;
	}

	public String getEmailAddress() {
		return EmailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		EmailAddress = emailAddress;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;
		User user = (User) o;
		return UserId == user.UserId;
	}

	@Override
	public int hashCode() {
		return Objects.hash(UserId);
	}
}
