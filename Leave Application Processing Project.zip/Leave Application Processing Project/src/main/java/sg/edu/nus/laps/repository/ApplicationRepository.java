package sg.edu.nus.laps.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import sg.edu.nus.laps.model.LeaveApplication;
import sg.edu.nus.laps.model.User;

public interface ApplicationRepository extends JpaRepository<LeaveApplication, Integer> {
	@Query("Select l from LeaveApplication as l where l.user.UserId = :k And l.State!='Deleted' AND (YEAR(l.StartDate) = YEAR(CURRENT_DATE) OR YEAR(l.EndDate) = YEAR(CURRENT_DATE))")
	public List<LeaveApplication> findAllHistoryByUserId(@Param("k") String userId);

	@Query("Select l from LeaveApplication as l where l.State!='Deleted' And l.user.ManagerId = :managerId AND (YEAR(l.StartDate) = YEAR(CURRENT_DATE) OR YEAR(l.EndDate) = YEAR(CURRENT_DATE)) ORDER BY l.user.UserId")
	public List<LeaveApplication> findAllSubordinateHistoryByUserId(@Param("managerId") String managerId);

	@Query("Select l from LeaveApplication as l where l.ApplicationId= :k")
	public LeaveApplication findLeaveApplicationById(@Param("k") Integer id);

	@Query("Select l from LeaveApplication as l where (l.State ='Applied' OR l.State='Updated') AND l.user.ManagerId = :managerId")
	public List<LeaveApplication> findAllApplicationsPendingForApproving(@Param("managerId") String managerId);

	@Modifying
	@Query("Delete from LeaveApplication as l where l.user= :user")
	public void deleteallrecords(@Param("user") User user);

	@Query("Select l from LeaveApplication as l where l.ApplicationId != :id AND ((l.StartDate <= :end And l.EndDate >= :start) OR (l.StartDate >= :end And l.EndDate <= :start))")
	public List<LeaveApplication> findOtherInPeriod(@Param("start") LocalDate start, @Param("end") LocalDate end,
			@Param("id") int applicationId);

	@Query("Select l from LeaveApplication as l WHERE l.State='Approved' AND ((YEAR(l.StartDate) = :year AND MONTH(l.StartDate) = :month) OR (YEAR(l.EndDate) = :year AND MONTH(l.EndDate) = :month))")
	public List<LeaveApplication> findAllLeaveIn(@Param("year") int year, @Param("month") int month);

	@Query("SELECT l FROM LeaveApplication l WHERE (l.StartDate <= :end AND l.EndDate >= :start) OR (l.StartDate >= :end AND l.EndDate <= :start)")
	public List<LeaveApplication> findAllInPeriod(@Param("start") LocalDate start, @Param("end") LocalDate end);

	@Query("SELECT l FROM LeaveApplication l WHERE l.user.UserId = :userId AND ((l.StartDate <= :end AND l.EndDate >= :start) OR (l.StartDate >= :end AND l.EndDate <= :start))")
	public List<LeaveApplication> findAllInPeriodByUserId(@Param("start") LocalDate start, @Param("end") LocalDate end,
			@Param("userId") String userId);

	@Query("SELECT l FROM LeaveApplication l WHERE l.ApplicationLeaveType = :leaveType AND ((l.StartDate <= :end AND l.EndDate >= :start) OR (l.StartDate >= :end AND l.EndDate <= :start))")
	public List<LeaveApplication> findAllInPeriodByLeaveType(@Param("start") LocalDate start,
			@Param("end") LocalDate end, @Param("leaveType") String leaveType);

	@Query("SELECT l FROM LeaveApplication l WHERE l.ApplicationLeaveType = :leaveType AND l.user.UserId = :userId AND ((l.StartDate <= :end AND l.EndDate >= :start) OR (l.StartDate >= :end AND l.EndDate <= :start))")
	public List<LeaveApplication> findAllInPeriodByUserIdAndLeaveType(@Param("start") LocalDate start,
			@Param("end") LocalDate end, @Param("userId") String userId, @Param("leaveType") String leaveType);

	@Query("SELECT DISTINCT l.user FROM LeaveApplication l WHERE l.State='Approved' AND ((l.StartDate <= :end AND l.EndDate >= :start) OR (l.StartDate >= :end AND l.EndDate <= :start))")
	public List<User> findUserByStartAndEnd(@Param("start") LocalDate start, @Param("end") LocalDate end);

	@Query("SELECT DISTINCT l.user FROM LeaveApplication l WHERE l.State='Approved' AND l.ApplicationLeaveType = :leaveType AND ((l.StartDate <= :end AND l.EndDate >= :start) OR (l.StartDate >= :end AND l.EndDate <= :start))")
	public List<User> findUserByStartAndEndAndLeaveType(@Param("start") LocalDate start, @Param("end") LocalDate end,
			@Param("leaveType") String leaveType);
}