package sg.edu.nus.laps.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import sg.edu.nus.laps.model.CompensationClaim;

public interface CompensationRepository extends JpaRepository<CompensationClaim, Integer>{
	@Query("Select c from CompensationClaim as c where c.user.UserId = :k And c.State!='Deleted'")
	public List<CompensationClaim> findAllHistoryByUserId(@Param("k") String userId);
	
	@Query("Select c from CompensationClaim as c where c.ClaimId = :k ")
	public CompensationClaim findClaimById(@Param("k") int id);
	
	@Query("Select c from CompensationClaim as c where c.user.ManagerId = :managerId AND (c.State ='Applied' OR c.State='Updated')")
	public List<CompensationClaim> findAllClaimsPendingForApproving(@Param("managerId") String managerId);
	
	@Query("Select c from CompensationClaim as c where (c.StartTime <= :end AND c.EndTime >= :start) OR (c.StartTime >= :end AND c.EndTime <= :start)")
	public List<CompensationClaim> findAllByStartAndEnd(@Param("start") LocalDateTime startDate, @Param("end")LocalDateTime endDate);
	
	@Query("Select c from CompensationClaim as c where c.user.UserId=:userId AND ((c.StartTime <= :end AND c.EndTime >= :start) OR (c.StartTime >= :end AND c.EndTime <= :start))")
	public List<CompensationClaim> findAllByStartAndEndAndUserId(@Param("start") LocalDateTime startDate, @Param("end")LocalDateTime endDate,@Param("userId") String userId);

	@Query("Select c from CompensationClaim as c where (c.State ='Applied' OR c.State='Updated') And ((c.StartTime <= :end AND c.EndTime >= :start) OR (c.StartTime >= :end AND c.EndTime <= :start))")
	public List<CompensationClaim> findAllByStartAndEndPendingForApproval(@Param("start") LocalDateTime startDate, @Param("end")LocalDateTime endDate);
	
	@Query("Select c from CompensationClaim as c where c.State= :state And ((c.StartTime <= :end AND c.EndTime >= :start) OR (c.StartTime >= :end AND c.EndTime <= :start))")
	public List<CompensationClaim> findAllByStartAndEndAndState(@Param("start") LocalDateTime startDate, @Param("end")LocalDateTime endDate ,@Param("state") String claimState);
	
	@Query("Select c from CompensationClaim as c where c.user.UserId = :userId AND (c.State ='Applied' OR c.State='Updated') And ((c.StartTime <= :end AND c.EndTime >= :start) OR (c.StartTime >= :end AND c.EndTime <= :start))")
	public List<CompensationClaim> findAllByStartAndEndAndUserIdPendingForApproval(@Param("start") LocalDateTime startDate, @Param("end")LocalDateTime endDate ,@Param("userId") String userId);
	
	@Query("Select c from CompensationClaim as c where c.user.UserId = :userId AND c.State= :state And ((c.StartTime <= :end AND c.EndTime >= :start) OR (c.StartTime >= :end AND c.EndTime <= :start))")
	public List<CompensationClaim> findAllByStartAndEndAndUserIdAndState(@Param("start") LocalDateTime startDate, @Param("end")LocalDateTime endDate ,@Param("userId") String userId,@Param("state") String claimState);
}
