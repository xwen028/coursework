package sg.edu.nus.laps.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import sg.edu.nus.laps.model.PublicHoliday;

public interface HolidayRepository extends JpaRepository<PublicHoliday,Integer>{
	@Query("Select h from PublicHoliday as h")
	public List<PublicHoliday> findAll();
	@Query("SELECT COUNT(p) FROM PublicHoliday p WHERE p.HolidayDate BETWEEN :startDate AND :endDate")
    public int countHolidaysBetweenDates(@Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);
	@Query("Select h from PublicHoliday as h Where h.HolidayId= :id")
	public PublicHoliday findHolidayById(@Param("id") int id);
}
