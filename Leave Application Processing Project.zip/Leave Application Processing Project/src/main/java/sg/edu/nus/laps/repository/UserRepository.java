package sg.edu.nus.laps.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import sg.edu.nus.laps.model.User;

public interface UserRepository extends JpaRepository<User, String> {
	@Query("Select u.Password from User as u where u.UserId = :k")
	public String SearchPasswordByUserId(@Param("k") String userId);

	@Query("Select u.UserType from User as u where u.UserId = :k")
	public String SearchUserTypeByUserId(@Param("k") String userId);

	@Query("Select u from User as u where u.UserId = :k")
	public User findByUserId(@Param("k") String userId);

	@Query("Select u from User as u where u.UserType!='Admin' ORDER BY u.UserType,u.ManagerId")
	public List<User> findAll();
	
	@Query("Select u.AnnualLeave from User as u where u.UserId = :k")
	public int SearchAnnualLeaveByUserId(@Param("k") String userId);
	
	@Query("Select u.MedicalLeave from User as u where u.UserId = :k")
	public int SearchMedicalLeaveByUserId(@Param("k") String userId);
	
	@Query("Select u.CompensationLeave from User as u where u.UserId = :k")
	public int SearchCompensationLeaveByUserId(@Param("k") String userId);
	
	@Modifying
	@Query("UPDATE User u SET u.AnnualLeave = u.AnnualLeave + :leavePeriod WHERE u.UserId = :userId")
	
	public void updateAnnualLeave(@Param("userId") String userId,@Param("leavePeriod") int leavePeriod);
	@Modifying
	@Query("UPDATE User u SET u.MedicalLeave = u.MedicalLeave + :leavePeriod WHERE u.UserId = :userId")
	public void updateMedicalLeave(@Param("userId") String userId,@Param("leavePeriod") int leavePeriod);
	
	@Modifying
	@Query("UPDATE User u SET u.CompensationLeave = u.CompensationLeave + :leavePeriod WHERE u.UserId = :userId")
	public void updateCompensationLeave(@Param("userId") String userId,@Param("leavePeriod") int leavePeriod);
	
}
