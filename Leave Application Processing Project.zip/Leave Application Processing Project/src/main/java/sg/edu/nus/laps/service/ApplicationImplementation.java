package sg.edu.nus.laps.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import jakarta.transaction.Transactional;
import sg.edu.nus.laps.model.LeaveApplication;
import sg.edu.nus.laps.model.User;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import sg.edu.nus.laps.interfacemethods.ApplicationInterface;
import sg.edu.nus.laps.repository.ApplicationRepository;
import sg.edu.nus.laps.repository.UserRepository;

@Service
@Transactional
public class ApplicationImplementation implements ApplicationInterface {

	@Autowired
	ApplicationRepository arepo;
	@Autowired
	UserRepository urepo;

	@Override
	@Transactional
	public void createApplication(String leaveType, LocalDate startDate, LocalDate endDate, User user,
			String additionalReason, String workDissemination, String contactDetail, int leavePeriod) {
		LeaveApplication newapplication = new LeaveApplication();
		newapplication.setApplicationLeaveType(leaveType);
		newapplication.setStartDate(startDate);
		newapplication.setEndDate(endDate);
		newapplication.setUser(user);
		newapplication.setAdditionalReason(additionalReason);
		newapplication.setWorkDissemination(workDissemination);
		newapplication.setContactDetail(contactDetail);
		newapplication.setLeavePeriod(leavePeriod);
		arepo.save(newapplication);

		return;
	}

	@Override
	@Transactional
	public boolean updateApplication(LeaveApplication application) {
		application.setState("Updated");
		if (arepo.save(application) != null)
			return true;
		else
			return false;

	}

	@Override
	@Transactional
	public boolean deleteApplication(LeaveApplication application) {
		application.setState("Deleted");
		if (arepo.save(application) != null)
			return true;
		else
			return false;
	}

	@Override
	@Transactional
	public boolean approveApplication(LeaveApplication application) {
		String UserId = application.getUser().getUserId();
		int LeavePeriod = application.getLeavePeriod();
		String LeaveType = application.getApplicationLeaveType();
		if (LeaveType.equals("Annual")) {
			urepo.updateAnnualLeave(UserId, -LeavePeriod);
		} else if (LeaveType.equals("Medical")) {
			urepo.updateMedicalLeave(UserId, -LeavePeriod);
		} else if (LeaveType.equals("Compensation")) {
			urepo.updateCompensationLeave(UserId, -LeavePeriod);
		}
		application.setState("Approved");
		if (arepo.save(application) != null)
			return true;
		else
			return false;
	}

	@Override
	@Transactional
	public boolean rejectApplication(LeaveApplication application, String rejectComment) {
		application.setState("Rejected");
		application.setRejectComment(rejectComment);
		if (arepo.save(application) != null)
			return true;
		else
			return false;
	}

	@Override
	@Transactional
	public boolean cancelApplication(LeaveApplication application) {
		String UserId = application.getUser().getUserId();
		int LeavePeriod = application.getLeavePeriod();
		String LeaveType = application.getApplicationLeaveType();
		if (LeaveType.equals("Annual")) {
			urepo.updateAnnualLeave(UserId, LeavePeriod);
		} else if (LeaveType.equals("Medical")) {
			urepo.updateMedicalLeave(UserId, LeavePeriod);
		} else if (LeaveType.equals("Compensation")) {
			urepo.updateCompensationLeave(UserId, LeavePeriod);
		}
		application.setState("Cancelled");
		if (arepo.save(application) != null)
			return true;
		else
			return false;
	}

	@Override
	@Transactional
	public List<LeaveApplication> findAllByUserId(String userId) {
		List<LeaveApplication> historylist = new ArrayList<>();
		historylist = arepo.findAllHistoryByUserId(userId);
		return historylist;
	};

	@Override
	@Transactional
	public List<LeaveApplication> findAllByManagerId(String managerId) {
		List<LeaveApplication> historylist = new ArrayList<>();
		historylist = arepo.findAllSubordinateHistoryByUserId(managerId);
		return historylist;
	};

	@Override
	@Transactional
	public List<LeaveApplication> findApprovingListByManagerId(String managerId) {
		List<LeaveApplication> approvinglist = new ArrayList<>();
		approvinglist = arepo.findAllApplicationsPendingForApproving(managerId);
		return approvinglist;
	};

	@Override
	@Transactional
	public LeaveApplication findById(Integer Id) {
		LeaveApplication app = arepo.findLeaveApplicationById(Id);
		return app;
	}

	@Override
	@Transactional
	public List<LeaveApplication> findOtherByStartAndEnd(LocalDate start, LocalDate end, int applicationId) {
		List<LeaveApplication> list = new ArrayList<>();
		list = arepo.findOtherInPeriod(start, end, applicationId);
		return list;
	}

	@Override
	@Transactional
	public List<LeaveApplication> findAllByYearAndMonth(int year, int month) {
		List<LeaveApplication> allleaves = new ArrayList<>();
		allleaves = arepo.findAllLeaveIn(year, month);
		return allleaves;
	}

	@Override
	@Transactional
	public List<LeaveApplication> findAllByStartAndEnd(LocalDate start, LocalDate end) {
		List<LeaveApplication> list = new ArrayList<>();
		list = arepo.findAllInPeriod(start, end);
		return list;
	}

	@Override
	@Transactional
	public List<LeaveApplication> findAllByStartAndEndAndUserId(LocalDate start, LocalDate end, String userId) {
		List<LeaveApplication> list = new ArrayList<>();
		list = arepo.findAllInPeriodByUserId(start, end, userId);
		return list;
	}

	@Override
	@Transactional
	public List<LeaveApplication> findAllByStartAndEndAndLeaveType(LocalDate start, LocalDate end, String leaveType) {
		List<LeaveApplication> list = new ArrayList<>();
		list = arepo.findAllInPeriodByLeaveType(start, end, leaveType);
		return list;
	}

	@Override
	@Transactional
	public List<LeaveApplication> findAllByStartAndEndAndUserIdAndLeaveType(LocalDate start, LocalDate end,
			String userId, String leaveType) {
		List<LeaveApplication> list = new ArrayList<>();
		list = arepo.findAllInPeriodByUserIdAndLeaveType(start, end, userId, leaveType);
		return list;
	}
	
	@Override
	@Transactional
	public List<User> findDistinctUserByStartAndEnd(LocalDate startDate,LocalDate endDate){
		List<User> list = new ArrayList<>();
		list = arepo.findUserByStartAndEnd(startDate, endDate);
		return list;
	}
	
	@Override
	@Transactional
	public List<User> findDistinctUserByStartAndEndAndLeaveType(LocalDate startDate,LocalDate endDate,String leaveType){
		List<User> list = new ArrayList<>();
		list = arepo.findUserByStartAndEndAndLeaveType(startDate, endDate,leaveType);
		return list;
	}
}
