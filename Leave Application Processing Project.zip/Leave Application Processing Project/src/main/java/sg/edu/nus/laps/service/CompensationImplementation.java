package sg.edu.nus.laps.service;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;
import sg.edu.nus.laps.interfacemethods.CompensationInterface;
import sg.edu.nus.laps.model.CompensationClaim;
import sg.edu.nus.laps.model.User;
import sg.edu.nus.laps.repository.CompensationRepository;
import sg.edu.nus.laps.repository.UserRepository;

@Service
@Transactional
public class CompensationImplementation implements CompensationInterface {
	
	@Autowired
	CompensationRepository crepo;
	
	@Autowired
	UserRepository urepo;
	
	@Override
	@Transactional
	public void createClaim(LocalDateTime startTime, LocalDateTime endTime,User user) {
		CompensationClaim newclaim = new CompensationClaim();
		newclaim.setStartTime(startTime);
		newclaim.setEndTime(endTime);
		newclaim.setUser(user);
		crepo.save(newclaim);
	}
	
	@Override
	@Transactional
	public List<CompensationClaim> showAllHistoryClaims(String userId){
		List<CompensationClaim> historys = new ArrayList<>();
		historys = crepo.findAllHistoryByUserId(userId);
		return historys;
	}
	
	public CompensationClaim findCompensationClaimById(int id) {
		CompensationClaim claim = crepo.findClaimById(id);
		return claim;
	}
	
	@Override
	@Transactional
	public boolean updateClaim(CompensationClaim claim) {
		claim.setState("Updated");
		if (crepo.save(claim) != null)
			return true;
		else
			return false;
	}
	@Override
	@Transactional
	public boolean deleteClaim(CompensationClaim claim) {
		claim.setState("Deleted");
		if (crepo.save(claim) != null)
			return true;
		else
			return false;
	}
	
	@Override
	@Transactional
	public boolean approveClaim(CompensationClaim claim) {
		claim.setState("Approved");
		String UserId = claim.getUser().getUserId();
		User user = urepo.findByUserId(UserId);
		Duration duration = Duration.between(claim.getStartTime(),claim.getEndTime());
        Long seconds = duration.getSeconds();
        user.setOverTimeSeconds(user.getOverTimeSeconds()+seconds);
        if(user.getOverTimeSeconds()>=3600*4)
        {
        	user.setOverTimeSeconds(user.getOverTimeSeconds()-3600*4);
        	user.setCompensationLeave(user.getCompensationLeave()+0.5);
        }
        urepo.save(user);
		if (crepo.save(claim) != null)
			return true;
		else
			return false;
	}
	
	
	@Override
	@Transactional
	public boolean rejectClaim(CompensationClaim claim,String rejectComment) {
		claim.setState("Rejected");
		claim.setRejectComment(rejectComment);
		if (crepo.save(claim) != null)
			return true;
		else
			return false;
	}
	
	@Override
	@Transactional
	public List<CompensationClaim> findClaimPendingForApproving(String managerId){
		List<CompensationClaim> approvinglist = new ArrayList<>();
		approvinglist = crepo.findAllClaimsPendingForApproving(managerId);
		return approvinglist;
	}
	@Override
	@Transactional
	public List<CompensationClaim> findAllByStartAndEnd(LocalDateTime startDate,LocalDateTime endDate){
		List<CompensationClaim> list = new ArrayList<>();
		list =crepo.findAllByStartAndEnd(startDate,endDate);
		return list;
	}
	
	@Override
	@Transactional
	public List<CompensationClaim> findAllByStartAndEndAndUserId(LocalDateTime startDate,LocalDateTime endDate,String userId){
		List<CompensationClaim> list = new ArrayList<>();
		list =crepo.findAllByStartAndEndAndUserId(startDate,endDate,userId);
		return list;
	}
	
	@Override
	@Transactional
	public List<CompensationClaim> findAllByStartAndEndPendingForApproval(LocalDateTime startDate,LocalDateTime endDate){
		List<CompensationClaim> list = new ArrayList<>();
		list =crepo.findAllByStartAndEndPendingForApproval(startDate,endDate);
		return list;
	}
	
	@Override
	@Transactional
	public List<CompensationClaim> findAllByStartAndEndAndState(LocalDateTime startDate,LocalDateTime endDate,String claimState){
		List<CompensationClaim> list = new ArrayList<>();
		list =crepo.findAllByStartAndEndAndState(startDate,endDate,claimState);
		return list;
	}
	
	@Override
	@Transactional
	public List<CompensationClaim> findAllByStartAndEndAndUserIdPendingForApproval(LocalDateTime startDate,LocalDateTime endDate,String userId){
		List<CompensationClaim> list = new ArrayList<>();
		list =crepo.findAllByStartAndEndAndUserIdPendingForApproval(startDate,endDate,userId);
		return list;
	}
	
	@Override
	@Transactional
	public List<CompensationClaim> findAllByStartAndEndAndUserIdAndState(LocalDateTime startDate,LocalDateTime endDate,String userId,String claimState){
		List<CompensationClaim> list = new ArrayList<>();
		list =crepo.findAllByStartAndEndAndUserIdAndState(startDate,endDate,userId,claimState);
		return list;
	}
}
