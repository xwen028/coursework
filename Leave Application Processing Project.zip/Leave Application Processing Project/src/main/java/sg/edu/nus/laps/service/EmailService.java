package sg.edu.nus.laps.service;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.stereotype.Service;

import java.util.Properties;

@Service
public class EmailService {

	// 发送邮件的方法
	public void sendEmailToManager(String recipientEmail, String userId) {
		// 邮箱配置
		final String username = "zhangten0131@gmail.com"; // 发送邮件的邮箱地址
		final String password = "c o s f uvao ofrk etnj"; // 邮箱密码或授权码

		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.gmail.com"); // 使用Gmail的SMTP服务器
		props.put("mail.smtp.port", "587");
		Session session = Session.getInstance(props, new Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		});

		try {
			// 创建 MimeMessage 对象
			Message message = new MimeMessage(session);
			// 设置发件人
			message.setFrom(new InternetAddress(username));
			// 设置收件人
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientEmail));
			// 设置邮件主题
			message.setSubject("Leave Application Created");
			// 设置邮件内容
			message.setText("Your subordinate " + userId
					+ " has created a new leave for you to review! link to login => http://localhost:8080/user/login");

			// 发送邮件
			Transport.send(message);

			System.out.println("Email sent successfully!");
		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}
	}

	public void sendEmailToEmployee(String recipientEmail, String leaveState) {
		// 邮箱配置
		final String username = "zhangten0131@gmail.com"; // 发送邮件的邮箱地址
		final String password = "c o s f uvao ofrk etnj"; // 邮箱密码或授权码

		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.gmail.com"); // 使用Gmail的SMTP服务器
		props.put("mail.smtp.port", "587");
		Session session = Session.getInstance(props, new Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		});

		try {
			// 创建 MimeMessage 对象
			Message message = new MimeMessage(session);
			// 设置发件人
			message.setFrom(new InternetAddress(username));
			// 设置收件人
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientEmail));
			// 设置邮件主题
			message.setSubject("Application State changes");
			// 设置邮件内容
			message.setText("Your Application has been "+leaveState+",link to login => http://localhost:8080/user/login");

			// 发送邮件
			Transport.send(message);

			System.out.println("Email sent successfully!");
		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}
	}
}