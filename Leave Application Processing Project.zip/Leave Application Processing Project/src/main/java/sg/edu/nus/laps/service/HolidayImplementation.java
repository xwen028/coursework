package sg.edu.nus.laps.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;
import sg.edu.nus.laps.interfacemethods.HolidayInterface;
import sg.edu.nus.laps.model.PublicHoliday;
import sg.edu.nus.laps.repository.HolidayRepository;

@Service
@Transactional
public class HolidayImplementation implements HolidayInterface {
	@Autowired
	HolidayRepository hrepo;

	@Override
	@Transactional
	public List<PublicHoliday> showAllHolidays() {
		List<PublicHoliday> allholidays = new ArrayList<>();
		allholidays = hrepo.findAll();
		return allholidays;
	}

	@Override
	@Transactional
	public void createHoliday(LocalDate holidayStartDate, LocalDate holidayEndDate, String description) {
		while (!holidayStartDate.isAfter(holidayEndDate)) {
			PublicHoliday newholiday = new PublicHoliday();
			newholiday.setDescription(description);
			newholiday.setHolidayDate(holidayStartDate);
			hrepo.save(newholiday);
			holidayStartDate = holidayStartDate.plusDays(1);
		}
	}
	@Override
	@Transactional
	public void updateHoliday(PublicHoliday publicholiday) {
		hrepo.save(publicholiday);
		return;
	}
	
	@Override
	@Transactional
	public void deleteHoliday(PublicHoliday publicholiday) {
		hrepo.delete(publicholiday);
		return;
	}
	
	@Override
	@Transactional
	public int countHolidayBetween(LocalDate holidayStartDate, LocalDate holidayEndDate) {
		;
		return hrepo.countHolidaysBetweenDates(holidayStartDate, holidayEndDate);
	}

	@Override
	@Transactional
	public PublicHoliday findHoliday(int id) {
		return hrepo.findHolidayById(id);
	}
}
