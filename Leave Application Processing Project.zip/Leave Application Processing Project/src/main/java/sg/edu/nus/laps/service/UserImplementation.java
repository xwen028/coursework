package sg.edu.nus.laps.service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import jakarta.transaction.Transactional;
import sg.edu.nus.laps.interfacemethods.UserInterface;
import sg.edu.nus.laps.model.User;
import sg.edu.nus.laps.repository.ApplicationRepository;
import sg.edu.nus.laps.repository.UserRepository;

@Service
@Transactional
public class UserImplementation implements UserInterface {
	@Autowired
	UserRepository urepo;
	@Autowired
	ApplicationRepository arepo;

	@Override
	@Transactional
	public boolean Vertify(String userid, String password) {
		if (urepo.SearchPasswordByUserId(userid) != null) {
			return urepo.SearchPasswordByUserId(userid).equals(password);
		}
		return false;
	}

	@Override
	@Transactional
	public String getType(String userid) {
		return urepo.SearchUserTypeByUserId(userid);
	}

	@Override
	@Transactional
	public boolean createUser(User user) {
		if (urepo.save(user) != null)
			return true;
		else
			return false;
	}

	@Override
	@Transactional
	public boolean updateUser(User user) {
		if (urepo.save(user) != null)
			return true;
		else
			return false;
	}

	@Override
	@Transactional
	public User findUser(String userId) {
		return urepo.findByUserId(userId);
	}

	@Override
	@Transactional
	public List<User> showAllUsers() {
		List<User> allusers = new ArrayList<>();
		allusers = urepo.findAll();
		return allusers;
	}

	@Override
	@Transactional
	public void deleteUser(User user) {
		arepo.deleteallrecords(user);
		urepo.delete(user);
		return;
	}

	@Override
	@Transactional
	public int findLeaveLeft(String userId, String leaveType) {
		if (leaveType.equals("Annual")) {
			return urepo.SearchAnnualLeaveByUserId(userId);
		} else if (leaveType.equals("Medical")) {
			return urepo.SearchMedicalLeaveByUserId(userId);
		} else if (leaveType.equals("Compensation")) {
			return urepo.SearchCompensationLeaveByUserId(userId);
		} else {
			return 0;
		}
	}

}
