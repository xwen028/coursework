package sg.edu.nus.laps;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LeaveApplicationProcessingProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
