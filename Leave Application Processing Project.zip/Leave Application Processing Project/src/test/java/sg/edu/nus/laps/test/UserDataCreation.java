package sg.edu.nus.laps.test;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import sg.edu.nus.laps.model.User;
import sg.edu.nus.laps.repository.UserRepository;

@SpringBootTest
public class UserDataCreation {
	@Autowired
	private UserRepository urepo;

	@Test
	void conTextLoad() {
		// Product
		User user1 = new User();
		user1.setUserId("Jacky");
		user1.setPassword("123");
		user1.setUserType("Admin");
		user1.setAnnualLeave(14);
		user1.setMedicalLeave(60);
		user1.setCompensationLeave(500);

		// Save
		urepo.save(user1);

	}
}
